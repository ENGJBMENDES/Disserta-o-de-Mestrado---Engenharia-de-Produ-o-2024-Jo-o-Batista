using namespace std;
#include "localSearch.h"
#include "ConstrutivoSetup.h"
#include "ConstrutivoRandom.h"
#include <iostream>
#include <limits>
#include <algorithm>

Results exchange(vector<int>& sequence, const DataSetup& data, vector<vector<int>>& matriz_speed) {

    vector<vector<float>> makespan;
    float min_makespan;
    //makespan = calcMakespanSetup(sequence, data, matriz_speed);
    min_makespan = numeric_limits<float>::max();

    int troca;
    vector<int> exchange_sequence = sequence;
    vector<int> bestSequence;

    for (int i = 0; i < data.n; i++) {
        for (int j = i + 1; j < data.n; j++) {
            troca = exchange_sequence[i];
            exchange_sequence[i] = sequence[j];
            exchange_sequence[j] = troca;

            /*for (int k = 0; k < data.n; k++) {
                cout << exchange_sequence[k] << " ";
            }
            cout << "\n";*/
            makespan = calcMakespanSetup(exchange_sequence, data, matriz_speed);
            //cout << makespan[data.n - 1] [data.m -1] << endl;
            


            if (makespan[data.n - 1][data.m - 1] < min_makespan) {
                min_makespan = makespan[data.n - 1][data.m - 1];
                bestSequence = exchange_sequence;
            }
            exchange_sequence = sequence;
        }
    }
    /*cout << "\nConsiderando a melhor sequencia atual, a sequencia encontrada com exchange com menor makespan eh:  " << endl;
    for (int k = 0; k < data.n; k++) {
        cout << bestSequence[k] << " ";
    }
    cout << "\nCom o makespan de: " << min_makespan << endl;*/
    //calcTEC(bestSequence, min_makespan, data, matriz_speed);

    Results Resultados;
    Resultados.sequence = bestSequence;
    //Resultados.energia = energia;
    Resultados.makespan = min_makespan;
    Resultados.matriz_velocidade = matriz_speed;

    return Resultados;
}

Results insertion(vector<int>& sequence, const DataSetup& data, vector<vector<int>>& matriz_speed) {

    vector<vector<float>> makespan;
    float min_makespan;
    //makespan = calcMakespanSetup(sequence, data, matriz_speed);
    min_makespan = numeric_limits<float>::max();

    int insertion_job;
    vector<int> insertion_sequence = sequence;
    vector<int> bestSequence;

    for (int i = 0; i < data.n; i++) {

        insertion_job = sequence[i];
        insertion_sequence.erase(insertion_sequence.begin() + i);

        for (int j = 0; j < data.n; j++) {

            if (i != j) {

                insertion_sequence.insert(insertion_sequence.begin() + j, insertion_job);

                /*for(int k = 0; k < data.n; k++){
                    cout << insertion_sequence[k] << " ";
                }
                cout << "\n";*/
                makespan = calcMakespanSetup(insertion_sequence, data, matriz_speed);
                //cout << makespan[data.n - 1][data.m -1] << endl;

                if (makespan[data.n - 1][data.m - 1] < min_makespan) {
                    min_makespan = makespan[data.n - 1][data.m - 1];
                    bestSequence = insertion_sequence;
                }
                insertion_sequence.erase(insertion_sequence.begin() + j);
            }

        }
        insertion_sequence = sequence;
    }
    /*cout << "\nConsiderando a melhor sequencia atual, a sequencia encontrada com insertion com menor makespan eh:  " << endl;
    for (int k = 0; k < data.n; k++) {
        cout << bestSequence[k] << " ";
    }
    cout << "\nCom o makespan de: " << min_makespan << endl;*/
    //calcTEC(bestSequence, min_makespan, data, matriz_speed);

    Results Resultados;
    Resultados.sequence = bestSequence;
    //Resultados.energia = energia;
    Resultados.makespan = min_makespan;
    Resultados.matriz_velocidade = matriz_speed;

    return Resultados;
}

Results OrOpt(vector<int>& sequence, const DataSetup& data, int KorOpt, vector<vector<int>>& matriz_speed) {

    vector<vector<float>> makespan;
    float min_makespan;
    //makespan = calcMakespanSetup(sequence, data, matriz_speed);
    min_makespan = numeric_limits<float>::max();

    vector<int> orOpt_jobs;
    vector<int> orOpt_sequence = sequence;
    vector<int> bestSequence;
    orOpt_jobs.resize(KorOpt);


    for (int i = 0; i <= data.n - KorOpt; i++) {

        for (int k = 0; k < KorOpt; k++) {
            orOpt_jobs[k] = orOpt_sequence[i];
            orOpt_sequence.erase(orOpt_sequence.begin() + i);
        }

        reverse(orOpt_jobs.begin(), orOpt_jobs.end());

        for (int j = 0; j <= data.n - KorOpt; j++) {

            if (i != j) {

                for (int k = 0; k < KorOpt; k++) {
                    orOpt_sequence.insert(orOpt_sequence.begin() + j, orOpt_jobs[k]);
                }

                /*for(int k = 0; k < data.n; k++){
                    cout << orOpt_sequence[k] << " ";
                }
                cout << "\n";*/
                makespan = calcMakespanSetup(orOpt_sequence, data, matriz_speed);
                //cout << makespan[data.n - 1][data.m -1] << endl;

                if (makespan[data.n - 1][data.m - 1] < min_makespan) {
                    min_makespan = makespan[data.n - 1][data.m - 1];
                    bestSequence = orOpt_sequence;
                }

                for (int k = 0; k < KorOpt; k++) {
                    orOpt_sequence.erase(orOpt_sequence.begin() + j);

                }

            }

        }
        orOpt_sequence = sequence;
    }
    /*cout << "\nConsiderando a melhor sequencia atual, a sequencia encontrada com Or-Opt-" << KorOpt << " com menor makespan eh:  " << endl;
    for (int k = 0; k < data.n; k++) {
        cout << bestSequence[k] << " ";
    }
    cout << "\nCom o makespan de: " << min_makespan << endl;*/
    //calcTEC(bestSequence, min_makespan, data, matriz_speed);

    Results Resultados;
    Resultados.sequence = bestSequence;
    //Resultados.energia = energia;
    Resultados.makespan = min_makespan;
    Resultados.matriz_velocidade = matriz_speed;

    return Resultados;
}

Results twoOpt(vector<int>& sequence, const DataSetup& data, vector<vector<int>>& matriz_speed) {

    vector<vector<float>> makespan;
    float min_makespan;
    //makespan = calcMakespanSetup(sequence, data, matriz_speed);
    min_makespan = numeric_limits<float>::max();

    vector <int> twoOpt_sequence;
    twoOpt_sequence = sequence;
    vector <int> best_sequence;

    for (int i = 0; i < data.n - 1; i++) {

        for (int j = i + 2; j <= data.n; j++) {

            reverse(twoOpt_sequence.begin() + i, twoOpt_sequence.begin() + j);

            /*for (int k =0; k< data.n; k++){
            cout << twoOpt_sequence[k] << " ";
            }
            cout << "\n";*/
            makespan = calcMakespanSetup(twoOpt_sequence, data, matriz_speed);
            //cout << makespan[data.n - 1] [data.m -1] << endl;

            if (makespan[data.n - 1][data.m - 1] < min_makespan) {
                min_makespan = makespan[data.n - 1][data.m - 1];
                best_sequence = twoOpt_sequence;
            }

            twoOpt_sequence = sequence;
        }
    }

    /*cout << "\nConsiderando a melhor sequencia atual, a sequencia encontrada com 2-opt com menor makespan eh:  " << endl;
    for (int k = 0; k < data.n; k++) {
        cout << best_sequence[k] << " ";
    }
    cout << "\nCom o makespan de: " << min_makespan << endl;*/
    //calcTEC(best_sequence, min_makespan, data, matriz_speed);

    Results Resultados;
    Resultados.sequence = best_sequence;
    //Resultados.energia = energia;
    Resultados.makespan = min_makespan;
    Resultados.matriz_velocidade = matriz_speed;

    return Resultados;
}

Results bloco_exchange(vector<int>& sequence, const DataSetup& data, int blocos, vector<vector<int>>& matriz_speed) {

    vector<vector<float>> makespan;
    float min_makespan;
    //makespan = calcMakespanSetup(sequence, data, matriz_speed);
    min_makespan = numeric_limits<float>::max();

    vector<int> troca;
    troca.resize(blocos);
    vector<int> exchange_sequence = sequence;
    vector<int> bestSequence;

    for (int i = 0; i <= data.n - blocos; i++) {
        for (int j = i + blocos; j <= data.n - blocos; j++) {
            for (int k = 0; k < blocos; k++) {
                troca[k] = exchange_sequence[i + k];
                exchange_sequence[i + k] = sequence[j + k];
                exchange_sequence[j + k] = troca[k];
            }
            /*for (int l = 0; l < data.n; l++){
                cout << exchange_sequence[l] << " ";
            }
            cout << "\n";*/
            makespan = calcMakespanSetup(exchange_sequence, data, matriz_speed);
            //cout << makespan[data.n - 1] [data.m -1] << endl;


            if (makespan[data.n - 1][data.m - 1] < min_makespan) {
                min_makespan = makespan[data.n - 1][data.m - 1];
                bestSequence = exchange_sequence;
            }
            exchange_sequence = sequence;
        }
    }
    /*cout << "\nConsiderando a melhor sequencia atual, a sequencia encontrada com bloco exchange " << blocos << " com menor makespan eh:  " << endl;
    for (int r = 0; r < data.n; r++) {
        cout << bestSequence[r] << " ";
    }
    cout << "\nCom o makespan de: " << min_makespan << endl;*/
    //calcTEC(bestSequence, min_makespan, data, matriz_speed);

    Results Resultados;
    Resultados.sequence = bestSequence;
    //Resultados.energia = energia;
    Resultados.makespan = min_makespan;
    Resultados.matriz_velocidade = matriz_speed;

    return Resultados;
}

Results VND_local_search(vector<int>& sequence, const DataSetup& data, float mkspn, vector<vector<int>>& matriz_speed) {

    int nbVizinhancas = 6;
    int i = 0;
    //vector<int> busca_sequence;
    vector<int> best_sequence = sequence;
    float makespan = mkspn;
    //vector<vector<float>> busca_makespan;
    Results busca;

    while (i < nbVizinhancas) {

        switch (i) {

        case 0:
            busca = exchange(best_sequence, data, matriz_speed);
            break;

        case 5:
            busca = bloco_exchange(best_sequence, data, 2, matriz_speed);
            break;

        case 1:
            busca = insertion(best_sequence, data, matriz_speed);
            break;

        case 3:
            busca = OrOpt(best_sequence, data, 2, matriz_speed);
            break;

        case 4:
            busca = OrOpt(best_sequence, data, 3, matriz_speed);
            break;

        case 2:
            busca = twoOpt(best_sequence, data, matriz_speed);
            break;
        }

        //busca_makespan = calcMakespanSetup(busca_sequence, data,matriz_speed);

        if (busca.makespan < makespan) {
            i = 0;
            best_sequence = busca.sequence;
            makespan = busca.makespan;
            //cout << "Houve melhora\n" << endl;
        }

        else {
            i++;
            //cout << "Nao houve melhora\n" << endl;
        }
    }

    /*cout << "\n\nPortanto, a melhor sequencia com busca local VND eh: ";
    for (int j = 0; j < data.n; j++) {
        cout << best_sequence[j] << " ";
    }*/

    //makespan = calcMakespanSetup(best_sequence, data, matriz_speed);
    //cout << "\nO menor makespan encontrado eh: " << makespan[data.n - 1][data.m - 1] << endl;

    float energia = calcTEC(best_sequence, makespan, data, matriz_speed);
    //cout << "A energia consumida eh: " << energia << endl;

    Results Resultados;
    Resultados.sequence = best_sequence;
    Resultados.energia = energia;
    Resultados.makespan = makespan;
    Resultados.matriz_velocidade = matriz_speed;
    
    return Resultados;
}


Results Swap_local_search(vector<int>& sequence, const DataSetup& data, float mkspn, vector<vector<int>>& matriz_speed) {

    int nbVizinhancas = 1;
    int i = 0;
    //vector<int> busca_sequence;
    vector<int> best_sequence = sequence;
    float makespan = mkspn;
    //vector<vector<float>> busca_makespan;
    Results busca;

    while (i < nbVizinhancas) {

        switch (i) {

        case 0:
            busca = exchange(best_sequence, data, matriz_speed);
            break;

            /*case 5:
                busca = bloco_exchange(best_sequence, data, 2, matriz_speed);
                break;

            case 1:
                busca = insertion(best_sequence, data, matriz_speed);
                break;

            case 3:
                busca = OrOpt(best_sequence, data, 2, matriz_speed);
                break;

            case 4:
                busca = OrOpt(best_sequence, data, 3, matriz_speed);
                break;

            case 2:
                busca = twoOpt(best_sequence, data, matriz_speed);
                break;*/
        }

        //busca_makespan = calcMakespanSetup(busca_sequence, data,matriz_speed);

        if (busca.makespan < makespan) {
            i = 0;
            best_sequence = busca.sequence;
            makespan = busca.makespan;
            //cout << "Houve melhora\n" << endl;
        }

        else {
            i++;
            //cout << "Nao houve melhora\n" << endl;
        }
    }

    /*cout << "\n\nPortanto, a melhor sequencia com busca local VND eh: ";
    for (int j = 0; j < data.n; j++) {
        cout << best_sequence[j] << " ";
    }*/

    //makespan = calcMakespanSetup(best_sequence, data, matriz_speed);
    //cout << "\nO menor makespan encontrado eh: " << makespan[data.n - 1][data.m - 1] << endl;

    float energia = calcTEC(best_sequence, makespan, data, matriz_speed);
    //cout << "A energia consumida eh: " << energia << endl;

    Results Resultados;
    Resultados.sequence = best_sequence;
    Resultados.energia = energia;
    Resultados.makespan = makespan;
    Resultados.matriz_velocidade = matriz_speed;

    return Resultados;
}


Results local_search_velocidades(vector<int>& sequence,
    const DataSetup& data,
    vector<vector<int>>& matriz_speed,
    int& nivel)
{
    vector<vector<float>> makespan;
    Results Resultados;

    Resultados.sequence = sequence;
    makespan = calcMakespanSetup(sequence, data, matriz_speed);
    Resultados.makespan = makespan[data.n - 1][data.m - 1];
    Resultados.energia = calcTEC(sequence, makespan[data.n - 1][data.m - 1], data, matriz_speed);
    Resultados.matriz_velocidade = matriz_speed;

    vector<vector<int>> matriz_velocidade = matriz_speed;
    vector<vector<int>> matriz_velocidade_nova = matriz_speed;
    vector<vector<float>> novo_makespan;
    while (nivel > 0) {
        vector<vector<float>> gaps;
        //cout << "\nCalculo da Matriz de Tempos e dos Gaps: " << endl;
        gaps = calcGaps(sequence, data, matriz_velocidade);


        //Ajustando Gap do Come\E7o pra o Fim sem estourar o makespan
        /*for (int i = 0; i < data.n - 1; i++) {
            for (int j = 0; j < data.m; j++) {
                if (gaps[i][j] >= 0.01) {
                    matriz_velocidade_nova[sequence.at(i)][j]--;
                    novo_makespan = calcMakespanSetup(sequence, data, matriz_velocidade_nova);
                    if (novo_makespan[data.n - 1][data.m - 1] > makespan[data.n - 1][data.m - 1]) {
                        break;
                    }
                    else {
                        matriz_velocidade = matriz_velocidade_nova;
                    }
                }
            }
        }*/

//Ajustando Gap do Fim pra o Come\E7o sem estourar o makespan
for (int i = data.n - 1; i > 0; i--) {
    for (int j = data.m; j > 0; j--) {
        if (gaps[i][j] >= 0.01 && matriz_velocidade_nova[sequence.at(i)][j] > 0) {
            matriz_velocidade_nova[sequence.at(i)][j]--;
            novo_makespan = calcMakespanSetup(sequence, data, matriz_velocidade_nova);
            if (novo_makespan[data.n - 1][data.m - 1] > makespan[data.n - 1][data.m - 1]) {
                break;
            }
            else {
                matriz_velocidade = matriz_velocidade_nova;
            }
        }
    }
}

//cout << "\nDiminuindo nivel de velocidade onde ha gap: " << endl;

/*std::cout.precision(3);
for (int i = 0; i < data.n; i++) {
    for (int j = 0; j < data.m; j++) {
        cout << fixed << matriz_velocidade[i][j] << "\t";
    }
    cout << "\n";
}

cout << "\nNova solucao: ";*/

makespan = calcMakespanSetup(sequence, data, matriz_velocidade);
//cout << "O makespan encontrado eh: " << makespan[data.n - 1][data.m - 1] << endl;

float energia = calcTEC(sequence, makespan[data.n - 1][data.m - 1], data, matriz_velocidade);
//cout << "A energia consumida eh: " << energia << endl;

Resultados.sequence = sequence;
Resultados.energia = energia;
Resultados.makespan = makespan[data.n - 1][data.m - 1];
Resultados.matriz_velocidade = matriz_velocidade;

nivel--;
    }
    return Resultados;
}


vector<vector<float>> Gap_J(vector<int>& sequence, const DataSetup& data, vector<vector<int>>& matriz_speed) {

    vector<vector<float>> matriz;
    matriz = calcMakespanSetup(sequence, data, matriz_speed);

    vector<vector<float>> matriz_gap_J;
    matriz_gap_J.resize(data.n);
    for (int i = 0; i < data.n; i++) {
        matriz_gap_J[i].resize(data.m);
    }

    for (int i = 0; i < data.n - 1; i++) {
        for (int j = 0; j < data.m; j++) {
            matriz_gap_J[i][j] = matriz[i+1][j] - matriz[i][j] - data.p[sequence.at(i+1)][j] / data.speed[j][matriz_speed[sequence.at(i + 1)][j]] - data.s[j][sequence.at(i) + 1][sequence.at(i + 1)];
        }
    }

    for (int j = 0; j < data.m - 1; j++) {
        matriz_gap_J[data.n - 1][j] = numeric_limits<float>::max();
    }

    matriz_gap_J[data.n - 1][data.m - 1] = 0;

    return matriz_gap_J;
}


vector<vector<float>> Gap_M(vector<int>& sequence, const DataSetup& data, vector<vector<int>>& matriz_speed) {

    vector<vector<float>> matriz;
    matriz = calcMakespanSetup(sequence, data, matriz_speed);

    vector<vector<float>> matriz_gap_M;
    matriz_gap_M.resize(data.n);
    for (int i = 0; i < data.n; i++) {
        matriz_gap_M[i].resize(data.m);
    }

    for (int i = 0; i < data.n; i++) {
        for (int j = 0; j < data.m - 1; j++) {
            matriz_gap_M[i][j] = matriz[i][j + 1] - matriz[i][j] - data.p[sequence.at(i)][j + 1] / data.speed[j+1][matriz_speed[sequence.at(i)][j + 1]];
        }
    }

    for (int i = 0; i < data.n - 1; i++) {
        matriz_gap_M[i][data.m - 1] = numeric_limits<float>::max();
    }

    matriz_gap_M[data.n - 1][data.m - 1] = 0;

    return matriz_gap_M;
}

vector<vector<float>> Gap(const DataSetup& data, vector<vector<float>>& Gap_J, vector<vector<float>>& Gap_M) {

    vector<vector<float>> matriz_gap;
    matriz_gap.resize(data.n);
    for (int i = 0; i < data.n; i++) {
        matriz_gap[i].resize(data.m);
    }
    
    for (int i = 0; i < data.n; i++){
        for (int j = 0; j < data.m; j++) {

            if (Gap_J[i][j] < Gap_M[i][j]) {
                matriz_gap[i][j] = Gap_J[i][j];
            }
            else {
                matriz_gap[i][j] = Gap_M[i][j];
            }
        }
    }

    return matriz_gap;
}

vector<pair<int,int>> G(const DataSetup& data, vector<vector<float>>& Gap) {

    vector<pair<int, int>> matriz_G;

    for (int i = 0; i < data.n; i++) {
        for (int j = 0; j < data.m; j++) {
            if (Gap[i][j] > 0){
                matriz_G.push_back(make_pair(i, j));
            }
        }
    }

    return matriz_G;
}

float calcTecUnit(vector<int> sequence,pair<int, int> G, const DataSetup& data, vector<vector<int>>& matriz_speed) {

    float TEC_Unit = 60 * data.p[sequence.at(G.first)][G.second] * data.lambda[G.second][matriz_speed[sequence.at(G.first)][G.second]] / (60 * matriz_speed[sequence.at(G.first)][G.second]);

    return TEC_Unit;
}

vector<float> E_C(vector<int> sequence,vector<pair<int, int>> G, const DataSetup& data, vector<vector<int>>& matriz_speed) {

    vector<float> EC;

    for (int i = 0; i < G.size(); i++) {
        EC.push_back(calcTecUnit(sequence, G[i], data, matriz_speed));
    }

    return EC;
}

float soma_Gap(const DataSetup& data, vector<vector<float>> Gap) {
    float soma_GAP = 0;

    for (int i = 0; i < data.n; i++) {
        for (int j = 0; j < data.m; j++) {
            soma_GAP = soma_GAP + Gap[i][j];
        }
    }

    return soma_GAP;
}

Results energy_saving(const DataSetup& data, vector<int> sequence, vector<vector<int>>& matriz_speed, float energy) {

    vector<vector<float>> GapJ = Gap_J(sequence, data, matriz_speed);
    vector<vector<float>> GapM = Gap_M(sequence, data, matriz_speed);
    vector<vector<float>> GAP = Gap(data, GapJ, GapM);
    vector<pair<int, int>> G_matrix = G(data, GAP);

    //float soma_GAP = soma_Gap(data, GAP);
    vector<vector<int>> matriz_velocidade;
    vector<float> delta_G;
    delta_G.resize(G_matrix.size());
    vector<float> delta_linha_G;
    delta_linha_G.resize(G_matrix.size());
    vector<float> EC_1;
    EC_1.resize(G_matrix.size());
    vector<float> EC_2;
    EC_2.resize(G_matrix.size());
    vector<float> EC_3;
    EC_3.resize(G_matrix.size());
    float Mx = 0;
    int q_max = 0;
    int a; 
    int b;
    bool teste = true;
    bool teste2 = true;
    vector<vector<float>> matriz_makespan;
    matriz_makespan = calcMakespanSetup(sequence, data, matriz_speed);
    float makespan;
    float TEC;

    while (teste == true) {

        teste = false;
        teste2 = false;
        matriz_velocidade = matriz_speed;
        EC_1 = E_C(sequence,G_matrix, data, matriz_velocidade);
        for (int q = 0; q < G_matrix.size(); q++) {
            if (matriz_speed[sequence.at(G_matrix[q].first)][G_matrix[q].second] != 0) {
                
                delta_G[q] = GAP[G_matrix[q].first][G_matrix[q].second];
                
                delta_linha_G[q] = data.p[sequence.at(G_matrix[q].first)][G_matrix[q].second] /
                    data.speed[G_matrix[q].second][matriz_speed[sequence.at(G_matrix[q].first)][G_matrix[q].second] - 1]
                     - data.p[sequence.at(G_matrix[q].first)][G_matrix[q].second] /
                    data.speed[G_matrix[q].second][matriz_speed[sequence.at(G_matrix[q].first)][G_matrix[q].second]];

                while (delta_G[q] - delta_linha_G[q] >= 0) {
                    //cout << "teste2";
                    teste = true;
                    matriz_speed[sequence.at(G_matrix[q].first)][G_matrix[q].second]--;

                    if (matriz_speed[sequence.at(G_matrix[q].first)][G_matrix[q].second] == 0) {
                        //cout << "teste3";
                        break;
                    }

                    delta_G[q] = GAP[G_matrix[q].first][G_matrix[q].second];

                    delta_linha_G[q] = data.p[sequence.at(G_matrix[q].first)][G_matrix[q].second] /
                        data.speed[G_matrix[q].second][matriz_speed[sequence.at(G_matrix[q].first)][G_matrix[q].second] - 1]
                        - data.p[sequence.at(G_matrix[q].first)][G_matrix[q].second] /
                        data.speed[G_matrix[q].second][matriz_speed[sequence.at(G_matrix[q].first)][G_matrix[q].second]];
                }

            }
        }
        if (!teste2) {
            break;
        }

        EC_2 = E_C(sequence,G_matrix, data, matriz_velocidade);

        for (int q = 0; q < EC_1.size(); q++) {
            EC_3[q] = EC_2[q] - EC_1[q];
            
            if (EC_3[q] > Mx) {
                Mx = EC_3[q];
                q_max = q;
            }
        }

        a = sequence.at(G_matrix[q_max].first);
        b = G_matrix[q_max].second;

        matriz_velocidade[a][b] = matriz_speed[a][b];

        matriz_speed = matriz_velocidade;

        matriz_makespan = calcMakespanSetup(sequence, data, matriz_speed);
        makespan = matriz_makespan[data.n - 1][data.m - 1];
        TEC = calcTEC(sequence, makespan, data, matriz_speed);
        energy = TEC;

        /*if (TEC >= energy) {
            teste = false;
        }
        else {
            energy = TEC;
            teste = true;
        }*/

        GapJ = Gap_J(sequence, data, matriz_speed);
        GapM = Gap_M(sequence, data, matriz_speed);
        GAP = Gap(data, GapJ, GapM);
        G_matrix = G(data, GAP);
        //soma_GAP = soma_Gap(data, GAP);
        //soma_GAP = 0;
        //cout << "teste4";
        //teste2 = false;
    }

    Results Solucao;
    Solucao.sequence = sequence;
    Solucao.energia = energy;
    Solucao.makespan = matriz_makespan[data.n - 1][data.m - 1];
    Solucao.matriz_velocidade = matriz_speed;



    return Solucao;
}


Results energy_saving_adaptado(const DataSetup& data, vector<int> sequence, vector<vector<int>>& matriz_speed, float makespan, float energy) {

    vector<vector<float>> GapJ = Gap_J(sequence, data, matriz_speed);
    vector<vector<float>> GapM = Gap_M(sequence, data, matriz_speed);
    vector<vector<float>> GAP = Gap(data, GapJ, GapM);
    vector<pair<int, int>> G_matrix = G(data, GAP);
   
    vector<vector<int>> matriz_velocidade = matriz_speed;
    vector<float> delta_G;
    delta_G.resize(G_matrix.size());
    vector<float> delta_linha_G;
    delta_linha_G.resize(G_matrix.size());


    
    //vector<vector<float>> matriz_makespan;
    //matriz_makespan = calcMakespanSetup(sequence, data, matriz_speed);
    //float TEC = calcTEC(sequence, matriz_makespan[data.n - 1][data.m - 1], data, matriz_speed);
    //cout << matriz_makespan[data.n - 1][data.m - 1] << "\t" << TEC << endl;

        for (int q = 0; q < G_matrix.size(); q++) {
            if (matriz_velocidade[sequence.at(G_matrix[q].first)][G_matrix[q].second] != 0) {

                delta_G[q] = GAP[G_matrix[q].first][G_matrix[q].second];

                delta_linha_G[q] = data.p[sequence.at(G_matrix[q].first)][G_matrix[q].second] /
                    data.speed[G_matrix[q].second][matriz_velocidade[sequence.at(G_matrix[q].first)][G_matrix[q].second] - 1]
                    - data.p[sequence.at(G_matrix[q].first)][G_matrix[q].second] /
                    data.speed[G_matrix[q].second][matriz_velocidade[sequence.at(G_matrix[q].first)][G_matrix[q].second]];

                while (delta_G[q] - delta_linha_G[q] >= 0) {

                    matriz_velocidade[sequence.at(G_matrix[q].first)][G_matrix[q].second]--;

                    if (matriz_velocidade[sequence.at(G_matrix[q].first)][G_matrix[q].second] == 0) {
                        break;
                    }

                    delta_G[q] = GAP[G_matrix[q].first][G_matrix[q].second] - delta_linha_G[q];

                    delta_linha_G[q] = data.p[sequence.at(G_matrix[q].first)][G_matrix[q].second] /
                        data.speed[G_matrix[q].second][matriz_velocidade[sequence.at(G_matrix[q].first)][G_matrix[q].second] - 1]
                        - data.p[sequence.at(G_matrix[q].first)][G_matrix[q].second] /
                        data.speed[G_matrix[q].second][matriz_velocidade[sequence.at(G_matrix[q].first)][G_matrix[q].second]];
                }

            }
            /*matriz_makespan = calcMakespanSetup(sequence, data, matriz_velocidade);
            TEC = calcTEC(sequence, matriz_makespan[data.n - 1][data.m - 1], data, matriz_velocidade);
            cout << matriz_makespan[data.n - 1][data.m - 1] << "\t" << TEC << endl;
            for (int i = 0; i < data.n; i++) {
                for (int j = 0; j < data.m; j++) {
                    cout << matriz_velocidade[i][j] << "\t";
                }
                cout << "\n";
            }
            getchar();*/
        }

        //matriz_makespan = calcMakespanSetup(sequence, data, matriz_velocidade);
        float TEC = calcTEC(sequence, makespan, data, matriz_velocidade);
        //cout << matriz_makespan[data.n - 1][data.m - 1] << "\t" << TEC << endl;
        //cout << "****************************" << endl;

    Results Solucao;
    Solucao.sequence = sequence;
    Solucao.energia = TEC;
    Solucao.makespan = makespan;
    Solucao.matriz_velocidade = matriz_velocidade;



    return Solucao;
}
