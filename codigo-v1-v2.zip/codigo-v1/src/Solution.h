#ifndef SOLUTION_H_INCLUDED
#define SOLUTION_H_INCLUDED

#include <vector>
//#include <limits>


struct Results {
    std::vector<int> sequence;
    std::vector<std::vector<int>> matriz_velocidade;
    float makespan;
    float energia;
    //float makespan{std::numeric_limits<float>::max()};
    //float energia{std::numeric_limits<float>::max()};
};


#endif // SOLUTION_H_INCLUDED
