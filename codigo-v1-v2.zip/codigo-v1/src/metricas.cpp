using namespace std;


#include "metricas.h"

float hypervolume(vector<Results> All_solution, pair<float,float> nadir_point) {

	float H = 0;

	H = (nadir_point.first - All_solution[0].makespan) * (nadir_point.second - All_solution[0].energia);

	for(int i = 1; i < All_solution.size() - 1; i++){
	
		H = H + (nadir_point.first - All_solution[i].makespan) * (All_solution[i].energia - All_solution[i+1].energia);
	}

	H = H / 1000000;

	//cout << "Hypervolume: " << H << endl;

	return H;
}