#ifndef PERTURBATION_H_INCLUDED
#define PERTURBATION_H_INCLUDED

#include <vector>
#include "Data.h"
#include "Solution.h"


std::vector<int> perturbation(std::vector<int>& sequence, const DataSetup& data, vector<vector<int>>& matriz_speed);
Results criterio_aceitacao(std::vector<int>& sequence, const DataSetup& data, vector<vector<int>>& matriz_speed);
std::vector<vector<int>> perturbation_speed(const DataSetup& data, vector<vector<int>>& matriz_speed, float p);

#endif // PERTURBATION_H_INCLUDED

