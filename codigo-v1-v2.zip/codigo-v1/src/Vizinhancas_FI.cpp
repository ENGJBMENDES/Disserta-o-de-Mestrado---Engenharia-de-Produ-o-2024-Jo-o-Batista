using namespace std;
#include "localSearch.h"
#include "ConstrutivoSetup.h"
#include <iostream>
#include <limits>
#include <algorithm>
#include "Vizinhancas_FI.h"
#include "NDS.h"


void segunda_fase(vector<Results>& X_E, const DataSetup& data) {
    Results Exchange_solution;
    vector <Results> P = X_E;
    vector <Results> P_a;
    vector<vector<float>> makespan;

    while (!P.empty()) {
        for (int k = 0; k < P.size(); k++) {
            Exchange_solution = exchange_teste(P[k], data);
            //cout << "exchange " << Exchange_solution.makespan << " " << Exchange_solution.energia << endl;
            Exchange_solution = energy_saving_adaptado(data, Exchange_solution.sequence, Exchange_solution.matriz_velocidade, Exchange_solution.makespan, Exchange_solution.energia);

            if (Exchange_solution.makespan < P[k].makespan  || Exchange_solution.energia < P[k].energia) {

                bool teste_X_E = false;

                for (int z = 0; z < X_E.size(); z++) {
                    teste_X_E = dominantes(X_E[z].makespan, X_E[z].energia, Exchange_solution.makespan, Exchange_solution.energia);

                    if (teste_X_E == true) {
                        break;
                    }
                }

                if (teste_X_E == false) {

                    int i = 0;
                    bool teste = false;

                    if (P_a.empty()) {
                        P_a.push_back(Exchange_solution);
                    }
                    else {
                        while (i < P_a.size()) {
                            if (abs(Exchange_solution.makespan - P_a[i].makespan) < 0.05 &&
                                abs(Exchange_solution.energia - P_a[i].energia) < 0.05) {
                                teste = true;
                                break;
                            }
                            i++;
                        }
                        if (teste == false) {
                            P_a.push_back(Exchange_solution);
                        }
                    }
                }
            }

            Exchange_solution = insertion_teste(P[k], data);
            //cout << "insertion " << Exchange_solution.makespan << " " << Exchange_solution.energia << endl;
            Exchange_solution = energy_saving_adaptado(data, Exchange_solution.sequence, Exchange_solution.matriz_velocidade, Exchange_solution.makespan, Exchange_solution.energia);

            if (Exchange_solution.makespan < P[k].makespan || Exchange_solution.energia < P[k].energia) {

                bool teste_X_E = false;

                for (int z = 0; z < X_E.size(); z++) {
                    teste_X_E = dominantes(X_E[z].makespan, X_E[z].energia, Exchange_solution.makespan, Exchange_solution.energia);

                    if (teste_X_E == true) {
                        break;
                    }
                }

                if (teste_X_E == false) {

                    int i = 0;
                    bool teste = false;

                    if (P_a.empty()) {
                        P_a.push_back(Exchange_solution);
                    }
                    else {
                        while (i < P_a.size()) {
                            if (abs(Exchange_solution.makespan - P_a[i].makespan) < 0.05 &&
                                abs(Exchange_solution.energia - P_a[i].energia) < 0.05) {
                                teste = true;
                                break;
                            }
                            i++;
                        }
                        if (teste == false) {
                            P_a.push_back(Exchange_solution);
                        }
                    }
                }
            }
        }


        cout << "\nSolucoes com segunda fase: " << endl;

        cout << "makespan" << "   " << "energia" << endl;
        for (int z = 0; z < P_a.size(); z++) {
            cout << P_a[z].makespan << "     " << P_a[z].energia << endl;
        }

        cout << "\n\n";


        if (!P_a.empty()) {
            for (int i = 0; i < P_a.size(); i++) {
                X_E.push_back(P_a[i]);
            }
        }

        Dominate(X_E);
        
        P.clear();
        P = P_a;
       
        P_a.clear();

    }

    cout << "\n\n";
}


Results exchange_teste(Results& solution, const DataSetup& data) {
    vector<int> exchange_sequence = solution.sequence;
    int troca;
    vector<vector<float>> makespan;
    bool teste;
    Results new_solution;

    for (int i = 0; i < data.n; i++) {
        for (int j = i + 1; j < data.n; j++) {
            troca = exchange_sequence[i];
            exchange_sequence[i] = solution.sequence[j];
            exchange_sequence[j] = troca;

            makespan = calcMakespanSetup(exchange_sequence, data, solution.matriz_velocidade);
            float energia = calcTEC(exchange_sequence, makespan[data.n - 1][data.m - 1], data, solution.matriz_velocidade);
            teste = dominantes(solution.makespan, solution.energia, makespan[data.n - 1][data.m - 1], energia);

            if (teste == false) {

                new_solution.sequence = exchange_sequence;
                new_solution.energia = energia;
                new_solution.makespan = makespan[data.n - 1][data.m - 1];
                //cout << makespan[data.n - 1][data.m - 1] << endl;
                //scout << energia << endl;
                new_solution.matriz_velocidade = solution.matriz_velocidade;

                return new_solution;
            }
            exchange_sequence = solution.sequence;
        }
    }
    return solution;
}




Results insertion_teste(Results& solution, const DataSetup& data) {

    vector<int> insertion_sequence = solution.sequence;
    int insertion_job;
    vector<vector<float>> makespan;
    bool teste;
    Results new_solution;

    for (int i = 0; i < data.n; i++) {

        insertion_job = solution.sequence[i];
        insertion_sequence.erase(insertion_sequence.begin() + i);

        for (int j = i + 1; j < data.n; j++) {
            if (i != j) {

                insertion_sequence.insert(insertion_sequence.begin() + j, insertion_job);

                makespan = calcMakespanSetup(insertion_sequence, data, solution.matriz_velocidade);
                float energia = calcTEC(insertion_sequence, makespan[data.n - 1][data.m - 1], data, solution.matriz_velocidade);

                teste = dominantes(solution.makespan, solution.energia, makespan[data.n - 1][data.m - 1], energia);


                if (teste == false) {

                    new_solution.sequence = insertion_sequence;
                    new_solution.energia = energia;
                    new_solution.makespan = makespan[data.n - 1][data.m - 1];
                    new_solution.matriz_velocidade = solution.matriz_velocidade;

                    return new_solution;
                }

                insertion_sequence.erase(insertion_sequence.begin() + j);
            }
        }
        insertion_sequence = solution.sequence;
    }
    return solution;
}



Results OrOpt_teste(Results& solution, const DataSetup& data, int KorOpt) {

    vector<int> orOpt_sequence = solution.sequence;
    vector<int> orOpt_jobs;
    orOpt_jobs.resize(KorOpt);
    vector<vector<float>> makespan;
    bool teste;
    Results new_solution;

    for (int i = 0; i <= data.n - KorOpt; i++) {

        for (int k = 0; k < KorOpt; k++) {
            orOpt_jobs[k] = orOpt_sequence[i];
            orOpt_sequence.erase(orOpt_sequence.begin() + i);
        }

        reverse(orOpt_jobs.begin(), orOpt_jobs.end());

        for (int j = i + 1; j <= data.n - KorOpt; j++) {

            if (i != j) {

                for (int k = 0; k < KorOpt; k++) {
                    orOpt_sequence.insert(orOpt_sequence.begin() + j, orOpt_jobs[k]);
                }

                makespan = calcMakespanSetup(orOpt_sequence, data, solution.matriz_velocidade);
                float energia = calcTEC(orOpt_sequence, makespan[data.n - 1][data.m - 1], data, solution.matriz_velocidade);

                teste = dominantes(solution.makespan, solution.energia, makespan[data.n - 1][data.m - 1], energia);


                if (teste == false) {

                    new_solution.sequence = orOpt_sequence;
                    new_solution.energia = energia;
                    new_solution.makespan = makespan[data.n - 1][data.m - 1];
                    new_solution.matriz_velocidade = solution.matriz_velocidade;

                    return new_solution;
                }

                for (int k = 0; k < KorOpt; k++) {
                    orOpt_sequence.erase(orOpt_sequence.begin() + j);

                }

            }

        }
        orOpt_sequence = solution.sequence;
    }
    return solution;
}



Results twoOpt_teste(Results& solution, const DataSetup& data) {

    vector<int> twoOpt_sequence = solution.sequence;
    vector<vector<float>> makespan;
    bool teste;
    Results new_solution;

    for (int i = 0; i < data.n; i++) {

        for (int j = i + 2; j <= data.n; j++) {

            reverse(twoOpt_sequence.begin() + i, twoOpt_sequence.begin() + j);

            makespan = calcMakespanSetup(twoOpt_sequence, data, solution.matriz_velocidade);
            float energia = calcTEC(twoOpt_sequence, makespan[data.n - 1][data.m - 1], data, solution.matriz_velocidade);

            teste = dominantes(makespan[data.n - 1][data.m - 1], energia, solution.makespan, solution.energia);


            if (teste == true) {

               new_solution.sequence = twoOpt_sequence;
               new_solution.energia = energia;
               new_solution.makespan = makespan[data.n - 1][data.m - 1];
               new_solution.matriz_velocidade = solution.matriz_velocidade;

               return new_solution;
            }

            twoOpt_sequence = solution.sequence;
        }

    }
    return solution;
}


Results bloco_exchange_teste(Results& solution, const DataSetup& data, int blocos) {

    vector<int> exchange_sequence = solution.sequence;
    vector<int> troca;
    troca.resize(blocos);
    vector<vector<float>> makespan;
    bool teste;
    Results new_solution;

    for (int i = 0; i <= data.n - blocos; i++) {
        for (int j = i + blocos; j <= data.n - blocos; j++) {
            for (int k = 0; k < blocos; k++) {
                troca[k] = exchange_sequence[i + k];
                exchange_sequence[i + k] = solution.sequence[j + k];
                exchange_sequence[j + k] = troca[k];
            }

            makespan = calcMakespanSetup(exchange_sequence, data, solution.matriz_velocidade);
            float energia = calcTEC(exchange_sequence, makespan[data.n - 1][data.m - 1], data, solution.matriz_velocidade);

            teste = dominantes(solution.makespan, solution.energia, makespan[data.n - 1][data.m - 1], energia);


            if (teste == false) {

                new_solution.sequence = exchange_sequence;
                new_solution.energia = energia;
                new_solution.makespan = makespan[data.n - 1][data.m - 1];
                new_solution.matriz_velocidade = solution.matriz_velocidade;

                return new_solution;
            }

            exchange_sequence = solution.sequence;
        }
    }
    return solution;
}