#ifndef VIZINHANCAS_FI_H_INCLUDED
#define VIZINHANCAS_FI_H_INCLUDED

#include "Data.h"
#include "Solution.h"

void segunda_fase(vector<Results>& X_E, const DataSetup& data);

Results exchange_teste(Results& solution, const DataSetup& data);

Results insertion_teste(Results& solution, const DataSetup& data);

Results OrOpt_teste(Results& solution, const DataSetup& data, int KorOpt);

Results twoOpt_teste(Results& solution, const DataSetup& data);

Results bloco_exchange_teste(Results& solution, const DataSetup& data, int blocos);

#endif // VIZINHANCAS_FI_H_INCLUDED
