#include <iostream>
#include <string>
#include <algorithm>
#include <fstream>
using namespace std;

#include "LeitorInstancia.h"
#include "ConstrutivoSetup.h"
#include "localSearch.h"
#include "ConstrutivoRandom.h"
#include "Timer.h"
#include "Vizinhancas_FI.h"
#include "metricas.h"
#include "NDS.h"
#include "Resultado.h"
#include "Modelos.h"


int main()
{
    std::vector<string> instancias;
    
//    instancias.push_back("input/SDST10_ta001.txt");
    instancias.push_back("input/instancia-ASA-arred.txt");

//    for (int i = 1; i < 10; i++) {
//        //instancias.push_back("SDST10_ta00" + to_string(i) + ".txt");
//        //instancias.push_back("SDST50_ta00" + to_string(i) + ".txt");
//        instancias.push_back("SDST100_ta00" + to_string(i) + ".txt");
//        instancias.push_back("SDST125_ta00" + to_string(i) + ".txt");
//    }

//    for (int i = 10; i < 91; i++) {
//        //instancias.push_back("SDST10_ta0" + to_string(i) + ".txt");
//        //instancias.push_back("SDST50_ta0" + to_string(i) + ".txt");
//        instancias.push_back("SDST100_ta0" + to_string(i) + ".txt");
//        instancias.push_back("SDST125_ta0" + to_string(i) + ".txt");
//    }

    int u = 0;
    while (u < instancias.size()) {

        /*pair<float, float> Nadir_point = NEH_Swap(instancias[u], "APAGAR_");
        NEH_Swap_2fase_energy_saving(instancias[u], "NEHRTB_Swap_2fase_Energy_Saving_", Nadir_point);
        NEH_Swap_energy_saving_2fase_energy_saving(instancias[u], "NEHRTB_Swap_Energy_Saving_2fase_Energy_Saving", Nadir_point);
        NEH_VND_energy_saving(instancias[u], "NEHRTB_VND_Energy_Saving_", Nadir_point);
        NEH_VND_2fase_energy_saving(instancias[u], "NEHRTB_VND_2fase_Energy_Saving_", Nadir_point);
        NEH_VND_energy_saving_2fase_energy_saving(instancias[u], "NEHRTB_VND_Energy_Saving_2fase_Energy_Saving_", Nadir_point);
        */

//        pair<float, float> Nadir_point = NEH_Swap(instancias[u], "NEHRTB_Swap_");
//        NEH_Swap_energy_saving(instancias[u], "NEHRTB_Swap_Energy_Saving_", Nadir_point);
//        NEH_Swap_2fase_energy_saving(instancias[u], "NEHRTB_Swap_2fase_Energy_Saving_", Nadir_point);
//        NEH_Swap_energy_saving_2fase_energy_saving(instancias[u], "NEHRTB_Swap_Energy_Saving_2fase_Energy_Saving", Nadir_point);
//        NEH_VND_energy_saving(instancias[u], "NEHRTB_VND_Energy_Saving_", Nadir_point);
//        NEH_VND_2fase_energy_saving(instancias[u], "NEHRTB_VND_2fase_Energy_Saving_", Nadir_point);
//        NEH_VND_energy_saving_2fase_energy_saving(instancias[u], "NEHRTB_VND_Energy_Saving_2fase_Energy_Saving_", Nadir_point);

		pair<float, float> Nadir_point = NEH_Swap_modifRK(instancias[u], "NEHRTB_Swap_");
		NEH_VND_energy_saving_modifRK(instancias[u], "NEHRTB_VND_Energy_Saving_", Nadir_point);
        

        u++;
    }
    return 0;
}
