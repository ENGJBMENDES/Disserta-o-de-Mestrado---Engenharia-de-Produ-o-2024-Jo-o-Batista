#include <iostream>
#include <string>
#include <fstream>
#include <cstdlib>
using namespace std;

#include "LeitorInstancia.h"

void carregarInstancia(string& nomeInstancia, Data& data) {

    ifstream inData(nomeInstancia, ios::in);
    if (!inData) {
        cerr << "File could not be opened" << endl;
        exit(1);
    }

    inData >> data.n;
    inData >> data.m;

    data.p.resize(data.n);
    for (int i = 0; i < data.n; i++) {
        data.p[i].resize(data.m);
    }

    for (int i = 0; i < data.n; i++) {
        for (int k = 0; k < data.m; k++) {
            inData >> data.p[i][k];
        }
    }
}


void carregarInstanciaSetup(string& nomeInstanciaSetup, DataSetup& data) {

    ifstream inDataSetup(nomeInstanciaSetup, ios::in);
    if (!inDataSetup) {
        cerr << "File could not be opened" << endl;
        exit(1);
    }

    inDataSetup >> data.n;
    inDataSetup >> data.m;

    data.p.resize(data.n);
    for (int i = 0; i < data.n; i++) {
        data.p[i].resize(data.m);
    }

    for (int i = 0; i < data.n; i++) {
        for (int k = 0; k < data.m; k++) {
            inDataSetup >> data.p[i][k];
        }
    }

    int n = data.n;
    n = n + 1;

    data.s.resize(data.m);
    for (int i = 0; i < data.m; i++) {
        data.s[i].resize(n);
        for (int j = 0; j < n; j++) {
            data.s[i][j].resize(data.n);
        }
    }

    for (int i = 0; i < data.m; i++) {
        for (int j = 0; j < n; j++) {
            for (int k = 0; k < data.n; k++) {
                inDataSetup >> data.s[i][j][k];
            }
        }
    }

//    data.speed.resize(3);
//    data.speed[0] = 0.8;
//    data.speed[1] = 1;
//    data.speed[2] = 1.2;

//    data.lambda.resize(3);
//    data.lambda[0] = 0.6;
//    data.lambda[1] = 1;
//    data.lambda[2] = 1.5;

    data.speed.resize(data.m);
    for (int i = 0; i < data.m; i++) {
        data.speed[i].resize(3);
        if ( i == 2 ) {
		    data.speed[i][0] = 0.8;
			data.speed[i][1] = 1;
			data.speed[i][2] = 1.2;
		} else {
		    data.speed[i][0] = data.speed[i][1] = data.speed[i][2] = 1;
		}
    }

    data.lambda.resize(data.m);
    for (int i = 0; i < data.m; i++) {
        data.lambda[i].resize(3);
        if ( i == 2 ) {
		    data.lambda[i][0] = 0.6;
			data.lambda[i][1] = 1;
			data.lambda[i][2] = 1.5;
		} else {
		    data.lambda[i][0] = data.lambda[i][1] = data.lambda[i][2] = 1;
		}
    }
}
