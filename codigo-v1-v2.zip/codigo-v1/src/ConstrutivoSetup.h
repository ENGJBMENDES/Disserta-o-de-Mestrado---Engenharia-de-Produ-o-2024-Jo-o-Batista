#ifndef CONSTRUTIVOSETUP_H_INCLUDED
#define CONSTRUTIVOSETUP_H_INCLUDED

#include "Data.h"
#include "Solution.h"

std::vector<pair<int, float>> calcTotalTimeSetup(const DataSetup& data, vector<vector<int>>& matriz_speed);

std::vector<pair<int, float>> sortAscendingSetup(vector<pair<int, float>>& tP);

std::vector<int> firstSecondPositionSetup(vector<pair<int, float>>& tP);

std::vector<vector<float>> calcMakespanSetup(vector<int>& sequence, const DataSetup& data, vector<vector<int>>& matriz_speed);

std::vector<int> bestInitialSequenceSetup(vector<int>& sequence, const DataSetup& data, vector<vector<int>>& matriz_speed);

std::vector<int> bestSequenceSetup(vector<pair<int, float>>& tP, vector<int>& sequence, const DataSetup& data, vector<vector<int>>& matriz_speed);

Results execute_construtivoSetup(const DataSetup& data, vector<vector<int>>& matriz_speed);

Results execute_construtivoSetup_NEHTRB(const DataSetup& data, vector<vector<int>>& matriz_speed);

float maior(float a, float b);

std::vector<vector<float>> mk_e(const DataSetup& data, vector<int>& sequence, int k, vector<vector<int>>& matriz_speed);

std::vector<vector<float>> mk_q(const DataSetup& data, vector<int>& sequence, int k, vector<vector<int>>& matriz_speed);

std::vector<vector<float>> mk_f(const DataSetup& data, vector<int>& sequence, int k, vector<vector<float>> e, vector<vector<float>> f, vector<vector<int>>& matriz_speed);

std::vector<float> greedy_f(const DataSetup& data, vector<int>& sequence, int j, vector<vector<float>> f, vector<vector<float>> q);

float calcTEC(std::vector<int>& sequence, const float makespan, const DataSetup& data, vector<vector<int>>& matriz_speed);

vector<vector<float>> calcGaps(vector<int>& sequence, const DataSetup& data, vector<vector<int>>& matriz_speed);


#endif // CONSTRUTIVOSETUP_H_INCLUDED

