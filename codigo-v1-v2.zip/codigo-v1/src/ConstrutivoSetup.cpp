#include <iostream>
#include <limits>
#include <vector>
#include <tuple> // pair, tuple
#include <algorithm>
using namespace std;

#include "ConstrutivoSetup.h"

Results execute_construtivoSetup_NEHTRB(const DataSetup& data, vector<vector<int>>& matriz_speed) {

    vector<pair<int, float>> ProdTime;
    ProdTime = calcTotalTimeSetup(data, matriz_speed);

    vector<pair<int, float>> SortedProdTime;
    SortedProdTime = sortAscendingSetup(ProdTime);

    vector<int> initial_sequence;
    initial_sequence = firstSecondPositionSetup(SortedProdTime);

    vector<int> best_initial_sequence;
    best_initial_sequence = bestInitialSequenceSetup(initial_sequence, data, matriz_speed);

    float minValue;

    for (int z = 2; z < data.n; z++) {

        vector<vector<float>> e;
        e = mk_e(data, best_initial_sequence, z, matriz_speed);

        vector<vector<float>> q;
        q = mk_q(data, best_initial_sequence, z, matriz_speed);


        vector<int> sequence_teste;

        vector<vector<float>> f;
        f.resize(data.m);
        for (int i = 0; i < data.m; i++) {
            f[i].resize(best_initial_sequence.size() + 1);
        }

        for (int i = 0; i <= best_initial_sequence.size(); i++) {
            sequence_teste = best_initial_sequence;
            sequence_teste.insert(sequence_teste.begin() + i, SortedProdTime.back().first);
            vector<vector<float>> f_teste;
            f_teste = mk_f(data, sequence_teste, i, e, f, matriz_speed);
            f = f_teste;
        }

        /*for (int i = 0; i < data.m; i++) {
            for (int j = 0; j < sequence_teste.size(); j++) {
                cout << f[i][j] << "\t";
            }
            cout << endl;
        }*/

        vector<float> greedy;
        vector<vector<float>> G;
        for (int i = 0; i < sequence_teste.size(); i++) {
            sequence_teste = best_initial_sequence;
            sequence_teste.insert(sequence_teste.begin() + i, SortedProdTime.back().first);
            greedy = greedy_f(data, sequence_teste, i, f, q);
            G.push_back(greedy);
        }

        /*for (int i = 0; i < G.size(); i++) {
            for (int j = 0; j < data.m; j++) {
                cout << G[i][j] << "\t";
            }
            cout << "\n";
        }
        cout << "\n";*/


        vector<pair<float, int>> mkspn;
        for (int i = 0; i < sequence_teste.size(); i++) {
            auto max_Element = max_element(G[i].begin(), G[i].end());
            float max_value = *max_Element;
            mkspn.push_back(make_pair(max_value, i));
        }

        /*for (int i = 0; i < mkspn.size(); i++) {
            cout << mkspn[i].first << "\t" << mkspn[i].second << endl;
        }*/

        auto minElement = std::min_element(mkspn.begin(), mkspn.end(),
            [](const std::pair<float, int>& p1, const std::pair<float, int>& p2) {
                return p1.first < p2.first;
            }
        );

        minValue = minElement->first;
        int posicao = minElement->second;


        best_initial_sequence.insert(best_initial_sequence.begin() + posicao, SortedProdTime.back().first);

        SortedProdTime.pop_back();

        /*for (int i = 0; i < best_initial_sequence.size(); i++) {
            cout << best_initial_sequence[i] << " ";
        }
        cout << "\n";
        cout << minValue << endl;*/

    }

    float TEC;
    TEC = calcTEC(best_initial_sequence, minValue, data, matriz_speed);
    //cout << "E a energia total consumida eh: " << TEC << endl;

    Results Resultados;

    Resultados.sequence = best_initial_sequence;
    Resultados.energia = TEC;
    Resultados.makespan = minValue;
    Resultados.matriz_velocidade = matriz_speed;

    return Resultados;
}

Results execute_construtivoSetup(const DataSetup& data, vector<vector<int>>& matriz_speed) {

    vector<pair<int, float>> ProdTime;
    ProdTime = calcTotalTimeSetup(data, matriz_speed);

    vector<pair<int, float>> SortedProdTime;
    SortedProdTime = sortAscendingSetup(ProdTime);

    vector<int> initial_sequence;
    initial_sequence = firstSecondPositionSetup(SortedProdTime);

    vector<int> best_initial_sequence;
    best_initial_sequence = bestInitialSequenceSetup(initial_sequence, data, matriz_speed);

    vector<int> best_sequence;
    best_sequence = bestSequenceSetup(SortedProdTime, best_initial_sequence, data, matriz_speed);

    vector<vector<float>> makespan = calcMakespanSetup(best_sequence, data, matriz_speed);

    float TEC;
    TEC = calcTEC(best_sequence, makespan[data.n - 1][data.m - 1], data, matriz_speed);
    //cout << "E a energia total consumida eh: " << TEC << endl;

    Results Resultados;

    Resultados.sequence = best_sequence;
    Resultados.energia = TEC;
    Resultados.makespan = makespan[data.n - 1][data.m - 1];
    Resultados.matriz_velocidade = matriz_speed;

    return Resultados;
}

vector<pair<int, float>> calcTotalTimeSetup(const DataSetup& data, vector<vector<int>>& matriz_speed) {

    vector<pair<int, float>> totProc;

    for (int i = 0; i < data.n; i++) {
        float proc = 0;
        for (int j = 0; j < data.m; j++) {
            proc = proc + data.p[i][j] / data.speed[j][matriz_speed[i][j]];
        }
        totProc.push_back(make_pair(i, proc));
    }

    /*for (int k = 0; k < totProc.size(); k++) {
        cout << totProc[k].first << "\t" << totProc[k].second << endl;
    }*/
    return totProc;
}


vector<pair<int, float>> sortAscendingSetup(vector<pair<int, float>>& tP) {

    auto sorter = [](const pair<int, float>& p1, const pair<int, float>& p2) {
        return p1.second < p2.second;
    };

    sort(tP.begin(), tP.end(), sorter);

    /*cout << "\nSorted" << endl;
    for (int k = 0; k < tP.size(); k++) {
        cout << tP[k].first << "\t" << tP[k].second << endl;
    }*/
    return tP;
}

vector<int> firstSecondPositionSetup(vector<pair<int, float>>& tP) {

    pair<int, float> primeiro = tP.back();
    tP.pop_back();
    pair<int, float> segundo = tP.back();
    tP.pop_back();

    vector<int> sequence;

    sequence.push_back(primeiro.first);
    sequence.push_back(segundo.first);

    /*cout << "\nOs dois jobs com os maiores tempos de processamento total sao: ";
    for (int i = 0; i < sequence.size(); i++) {
        cout << sequence[i] << " ";
    }
    cout << "\n";*/
    return sequence;
}


vector<vector<float>> calcMakespanSetup(vector<int>& sequence, const DataSetup& data, vector<vector<int>>& matriz_speed) {


    //cout << "\nTempos para sequencia: ";
    for (int i = 0; i < sequence.size(); i++) {
        //cout << sequence[i] << " ";
    }
    //cout << "\n";

    //defini��o e dimensionamento makespan
    vector<vector<float>> makespan;
    makespan.resize(data.n);
    for (int i = 0; i < data.n; i++) {
        makespan[i].resize(data.m);
    }

    // tempos do primeiro job da sequencia pra o makespan
    makespan[0][0] = data.p[sequence.front()][0] / data.speed[0][matriz_speed[sequence.front()][0]] + data.s[0][0][sequence.front()];
    //cout << makespan[0][0] << "\t";

    float aux = makespan[0][0];
    for (int j = 1; j < data.m; j++) {
        aux += data.p[sequence.front()][j] / data.speed[j][matriz_speed[sequence.front()][j]];
        makespan[0][j] = aux;
        //cout << makespan[0][j] << "\t";
    }

    //cout << "\n";

// tempos a partir do primeiro job da sequencia pra o makespan
    for (int i = 1; i < sequence.size(); i++) {
        for (int j = 0; j < data.m; j++) {
            if (j == 0) {
                makespan[i][j] = makespan[i - 1][j] + data.p[sequence.at(i)][j] / data.speed[j][matriz_speed[sequence.at(i)][j]] + data.s[j][sequence.at(i - 1) + 1][sequence.at(i)];
            }
            else {
                if (makespan[i][j - 1] >= makespan[i - 1][j] + data.s[j][sequence.at(i - 1) + 1][sequence.at(i)]) {
                    makespan[i][j] = makespan[i][j - 1] + data.p[sequence.at(i)][j] / data.speed[j][matriz_speed[sequence.at(i)][j]];
                }

                else {
                    makespan[i][j] = makespan[i - 1][j] + data.p[sequence.at(i)][j] / data.speed[j][matriz_speed[sequence.at(i)][j]] + data.s[j][sequence.at(i - 1) + 1][sequence.at(i)];
                }

            }
            //cout << makespan[i][j] << "\t";
        }
        //cout << "\n";
    }

    return makespan;
}


vector<int> bestInitialSequenceSetup(vector<int>& sequence, const DataSetup& data, vector<vector<int>>& matriz_speed) {

    vector<vector<float>> makespan;
    makespan = calcMakespanSetup(sequence, data, matriz_speed);

    float minimum_makespan = makespan[sequence.size() - 1][data.m - 1];
    vector<int> best_sequence = sequence;
    //cout << "O makespan para essa sequencia eh: " << minimum_makespan << endl;

    reverse(sequence.begin(), sequence.end());
    makespan = calcMakespanSetup(sequence, data, matriz_speed);
    //cout << "O makespan para essa sequencia eh: " << makespan[sequence.size() - 1][data.m - 1] << endl;


    if (makespan[sequence.size() - 1][data.m - 1] < minimum_makespan) {
        minimum_makespan = makespan[sequence.size() - 1][data.m - 1];
        best_sequence = sequence;
    }

    /*cout << "\nPortanto, a melhor sequencia eh: ";
    for (int i = 0; i < sequence.size(); i++) {
        cout << best_sequence[i] << " ";
    }
    cout << "\nCom o makespan de: " << minimum_makespan << endl << "\n";*/

    return best_sequence;
}


vector<int> bestSequenceSetup(vector<pair<int, float>>& tP, vector<int>& sequence, const DataSetup& data, vector<vector<int>>& matriz_speed) {


    vector<vector<float>> makespan;
    pair<int, float> new_job;
    vector<int> best_sequence;


    while (!tP.empty()) {

        new_job = tP.back();
        tP.pop_back();

        float minimum_makespan = numeric_limits<float>::max();

        //cout << "Inserindo o Job " << new_job.first << " na sequencia: " << endl << "\n";

        for (int i = 0; i <= sequence.size(); i++) {

            sequence.insert(sequence.begin() + i, new_job.first);

            /*for (int j = 0; j < sequence.size(); j++) {
                cout << sequence[j] << " ";
            }*/

            makespan = calcMakespanSetup(sequence, data, matriz_speed);

            if (makespan[sequence.size() - 1][data.m - 1] < minimum_makespan) {
                minimum_makespan = makespan[sequence.size() - 1][data.m - 1];
                best_sequence = sequence;
            }
            //cout << "O makespan eh: " << makespan[sequence.size() - 1][data.m - 1] << endl << "\n";

            sequence.erase(sequence.begin() + i);
        }

        sequence = best_sequence;

        /*cout << "A melhor sequencia incluindo " << new_job.first << " eh: " << endl;
        for (int j = 0; j < best_sequence.size(); j++) {
            cout << best_sequence[j] << " ";
        }
        cout << "\nCom o makespan de: " << minimum_makespan << endl << "\n";
        cout << "\n";*/
    }

    /*cout << "Portanto, a sequencia final eh: ";
    for (int j = 0; j < best_sequence.size(); j++) {
        cout << best_sequence[j] << " ";
    }
    cout << "\n";

    makespan = calcMakespanSetup(best_sequence, data, matriz_speed);
    cout << "Com o makespan de: " << makespan[data.n - 1][data.m - 1] << endl;*/

    return best_sequence;
}


float maior(float a, float b) {
    return a > b ? a : b;
}

vector<vector<float>> mk_e(const DataSetup& data, vector<int>& sequence, int k, vector<vector<int>>& matriz_speed) {

    vector<vector<float>> e;
    e.resize(data.m);
    for (int i = 0; i < data.m; i++) {
        e[i].resize(sequence.size());
    }

    for (int j = 0; j < k; j++) {

        if (j == 0) {
            e[0][0] = data.p[sequence.at(0)][0] / data.speed[0][matriz_speed[sequence.at(0)][0]];
            for (int i = 1; i < data.m; i++) {
                e[i][0] = e[i - 1][0] + data.p[sequence.at(0)][i] / data.speed[i][matriz_speed[sequence.at(0)][i]];
            }
        }


        else {
            e[0][j] = e[0][j - 1] + data.s[0][sequence.at(j - 1) + 1][sequence.at(j)] + data.p[sequence.at(j)][0] / data.speed[0][matriz_speed[sequence.at(j)][0]];
            for (int i = 1; i < data.m; i++) {
                e[i][j] = maior(e[i - 1][j], e[i][j - 1] + data.s[i][sequence.at(j - 1) + 1][sequence.at(j)]) + data.p[sequence.at(j)][i] / data.speed[i][matriz_speed[sequence.at(j)][i]];
            }
        }

    }

    /*for (int i = 0; i < data.m; i++) {
        for (int j = 0; j < sequence.size(); j++) {
            cout << e[i][j] << "\t";
        }
        cout << endl;
    }*/

    return e;
}


vector<vector<float>> mk_q(const DataSetup& data, vector<int>& sequence, int k, vector<vector<int>>& matriz_speed) {

    vector<vector<float>> q;
    q.resize(data.m);
    for (int i = 0; i < data.m; i++) {
        q[i].resize(sequence.size());
    }

    for (int j = k - 1; j > -1; j--) {

        if (j == sequence.size() - 1) {
            q[data.m - 1][sequence.size() - 1] = data.p[sequence.at(sequence.size() - 1)][data.m - 1] / data.speed[data.m - 1][matriz_speed[sequence.at(sequence.size() - 1)][data.m - 1]];
            for (int i = data.m - 2; i > -1; i--) {
                q[i][j] = q[i + 1][j] + data.p[sequence.at(j)][i] / data.speed[i][matriz_speed[sequence.at(j)][i]];
            }
        }


        else {
            q[data.m - 1][j] = q[data.m - 1][j + 1] + data.s[data.m - 1][sequence.at(j) + 1][sequence.at(j + 1)] + data.p[sequence.at(j)][data.m - 1] / data.speed[data.m - 1][matriz_speed[sequence.at(j)][data.m - 1]];
            for (int i = data.m - 2; i > -1; i--) {
                q[i][j] = maior(q[i + 1][j], q[i][j + 1] + data.s[i][sequence.at(j) + 1][sequence.at(j + 1)]) + data.p[sequence.at(j)][i] / data.speed[i][matriz_speed[sequence.at(j)][i]];
            }
        }

    }

    /*for (int i = 0; i < data.m; i++) {
        for (int j = 0; j < sequence.size(); j++) {
            cout << q[i][j] << "\t";
        }
        cout << endl;
    }*/

    return q;
}


vector<vector<float>> mk_f(const DataSetup& data, vector<int>& sequence, int j, vector<vector<float>> e, vector<vector<float>> f, vector<vector<int>>& matriz_speed) {

    if (j == 0) {
        f[0][j] = data.p[sequence.at(j)][0] / data.speed[0][matriz_speed[sequence.at(j)][0]];
        for (int i = 1; i < data.m; i++) {
            f[i][j] = f[i - 1][j] + data.p[sequence.at(j)][i] / data.speed[i][matriz_speed[sequence.at(j)][i]];
        }
    }


    else {
        f[0][j] = e[0][j - 1] + data.s[0][sequence.at(j - 1) + 1][sequence.at(j)] + data.p[sequence.at(j)][0] / data.speed[0][matriz_speed[sequence.at(j)][0]];
        for (int i = 1; i < data.m; i++) {
            f[i][j] = maior(f[i - 1][j], e[i][j - 1] + data.s[i][sequence.at(j - 1) + 1][sequence.at(j)]) + data.p[sequence.at(j)][i] / data.speed[i][matriz_speed[sequence.at(j)][i]];
        }
    }

    return f;
}

vector<float> greedy_f(const DataSetup& data, vector<int>& sequence, int j, vector<vector<float>> f, vector<vector<float>> q) {

    float mk;
    vector<float> mk_row;

    if (j < sequence.size() - 1) {
        for (int i = 0; i < data.m; i++) {
            mk = f[i][j] + data.s[i][sequence.at(j) + 1][sequence.at(j + 1)] + q[i][j];
            mk_row.push_back(mk);
        }
    }

    if (j == sequence.size() - 1) {
        for (int i = 0; i < data.m; i++) {
            mk = f[i][j];
            mk_row.push_back(mk);
        }
    }

    return mk_row;
}


float calcTEC(vector<int>& sequence, const float makespan, const DataSetup& data, vector<vector<int>>& matriz_speed) {

    vector<float> power;
    power.resize(data.m);
    for (int i = 0; i < data.m; i++) {
        power[i] = 60;
    }

    float upsilon = 0.05;

    /*vector<vector<vector<int>>> y;
    y.resize(data.m);
    for (int i = 0; i < data.m; i++) {
        y[i].resize(data.n);
        for (int j = 0; j < data.n; j++) {
            y[i][j].resize(data.speed.size());
        }
    }

    for (int i = 0; i < data.m; i++) {
        for (int j = 0; j < data.n; j++) {
            y[i][j][1] = 1;
        }
    }*/

   vector<vector<float>> matriz_lambda;
   
    matriz_lambda.resize(data.m);
    for (int i = 0; i < data.m; i++) {
        matriz_lambda[i].resize(data.n);
    }

    for (int i = 0; i < data.m; i++) {
        for (int j = 0; j < data.n; j++) {
            if (data.speed[i][matriz_speed[j][i]] == data.speed[i][0]){
                matriz_lambda[i][j] = data.lambda[i][0];
            }
            if (data.speed[i][matriz_speed[j][i]] == data.speed[i][1]){
                matriz_lambda[i][j] = data.lambda[i][1];
             }
            if (data.speed[i][matriz_speed[j][i]] == data.speed[i][2]){
                matriz_lambda[i][j] = data.lambda[i][2];
             }
                
        }
    }

    vector<float> theta;
    theta.resize(data.m);

    for (int i = 0; i < data.m; i++) {

        theta[i] = 0;

        for (int j = 0; j < data.n; j++) {

            theta[i] += -data.p[j][i] / data.speed[i][matriz_speed[j][i]];
        }
        theta[i] += makespan;
    }

    float TEC = 0;

    for (int i = 0; i < data.m; i++) {
        for (int j = 0; j < data.n; j++) {
            TEC += power[i] * data.p[j][i] * matriz_lambda[i][j] / (60 * data.speed[i][matriz_speed[j][i]]);
        }
        TEC += power[i] * upsilon * theta[i] / 60;
    }

    //cout << "E a energia total consumida eh: " << TEC << endl;

    return TEC;
}



vector<vector<float>> calcGaps(vector<int>& sequence, const DataSetup& data, vector<vector<int>>& matriz_speed) {

    vector<vector<float>> matriz;
    matriz = calcMakespanSetup(sequence, data, matriz_speed);

    /*for (int i = 0; i < data.n; i++) {
        for (int j = 0; j < data.m; j++) {

            cout << matriz[i][j] << "\t";
        }
        cout << "\n";
    }

    cout << "\n";*/

    vector<vector<float>> matriz_gap_J;
    matriz_gap_J.resize(data.n);
    for (int i = 0; i < data.n; i++) {
        matriz_gap_J[i].resize(data.m);
    }

    for (int i = 0; i < data.n - 1; i++) {
        for (int j = 0; j < data.m; j++) {
            matriz_gap_J[i][j] = matriz[i + 1][j] - matriz[i][j] - data.p[sequence.at(i + 1)][j]/ data.speed[j][matriz_speed[sequence.at(i + 1)][j]] - data.s[j][sequence.at(i) + 1][sequence.at(i + 1)];
            //cout << matriz_gap_J[i][j] << "\t";
        }
        //cout << "\n";
    }

    return matriz_gap_J;
}

