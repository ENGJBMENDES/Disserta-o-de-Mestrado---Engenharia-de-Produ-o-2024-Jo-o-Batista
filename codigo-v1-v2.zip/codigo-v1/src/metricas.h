#ifndef METRICAS_H_INCLUDED
#define METRICAS_H_INCLUDED


#include <iostream>
#include <vector>
#include <cmath>
#include <limits>
#include "Solution.h"

float hypervolume(vector<Results> All_solution, pair<float, float> nadir_point);

#endif // METRICAS_H_INCLUDED