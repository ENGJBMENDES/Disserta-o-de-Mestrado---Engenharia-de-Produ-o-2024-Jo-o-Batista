#ifndef CONSTRUTIVORANDOM_H_INCLUDED
#define CONSTRUTIVORANDOM_H_INCLUDED

#include <vector>
#include "Data.h"
#include "Solution.h"

Results sequenceRandom(const DataSetup& data, vector<vector<float>>& matriz_speed);

#endif // CONSTRUTIVORANDOM_H_INCLUDED

