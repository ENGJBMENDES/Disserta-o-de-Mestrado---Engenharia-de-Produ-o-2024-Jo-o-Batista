using namespace std;
#include "Resultado.h"

void escrever_nds(vector<Results> All_Solution, string instancePath, string modelo) {
	
    // salvando makespan e energia das solu��es n�o dominadas em arquivo pra pareto front

    ofstream arquivo;

	string nomeInstanciaSetup = obtemNomeDaInstancia(instancePath);
	
    arquivo.open("Final/nds/" + modelo + nomeInstanciaSetup + ".txt", ios::out);

    for (int i = 0; i < All_Solution.size(); i++) {
        arquivo << All_Solution[i].makespan << " " << All_Solution[i].energia << endl;
    }

    arquivo.close();

}

void escrever_solucao_completa(vector<Results> All_Solution, string instancePath, double CPU_Time, float hipervolume, const DataSetup& dataSetup, string modelo) {

    //salvando solu��es n�o dominadas em arquivo

    ofstream arquivo;
    
	string nomeInstanciaSetup = obtemNomeDaInstancia(instancePath);

    arquivo.open("Final/solucao_completa/" + modelo + nomeInstanciaSetup + ".txt", ios::out);

    arquivo << "CPU TIME: " << CPU_Time << endl;

    arquivo << "Hypervolume: " << hipervolume << endl;

    for (int i = 0; i < All_Solution.size(); i++) {
        arquivo << "Solucao " << i + 1 << endl;

        arquivo << "Sequencia" << endl;
        for (int j = 0; j < All_Solution[i].sequence.size(); j++) {

            arquivo << All_Solution[i].sequence[j] << " ";

        }
        arquivo << "\nMakespan: " << All_Solution[i].makespan << endl;
        arquivo << "Energia: " << All_Solution[i].energia << endl;

        arquivo << "Matriz de Nivel de Velocidade" << endl;
        for (int n = 0; n < dataSetup.n; n++) {
            for (int m = 0; m < dataSetup.m; m++) {
                arquivo << All_Solution[i].matriz_velocidade[n][m] << " ";

            }
            arquivo << "\n";
        }
        arquivo << "\n";
    }

    arquivo.close();
	
}

void escrever_resumo(vector<Results> All_Solution, string nomeInstanciaSetup, double CPU_Time, float hipervolume, string modelo) {

    //resumo de metricas

    ofstream arquivo;

    arquivo.open("Final/" + modelo + ".txt", ios::app);

    arquivo << nomeInstanciaSetup << " " << CPU_Time << " " << hipervolume << " " << All_Solution.size() << endl;

    arquivo.close();
	
}

string obtemNomeDaInstancia( string instancePath )
{

	string nomeDaInstancia;

	string::size_type loc = instancePath.find_last_of(".", instancePath.size() );
	string::size_type loc2 = instancePath.find_last_of("/", instancePath.size() );

	if (loc != string::npos) {
		nomeDaInstancia.append(instancePath, loc2+1, loc-loc2-1 );
	}
	else {
		nomeDaInstancia.append(instancePath, loc2+1, instancePath.size() );
	}
	
	return nomeDaInstancia;

}
