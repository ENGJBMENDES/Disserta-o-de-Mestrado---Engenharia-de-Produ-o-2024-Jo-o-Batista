#ifndef LEITORINSTANCIA_H_INCLUDED
#define LEITORINSTANCIA_H_INCLUDED

#include<string>

#include "Data.h"

void carregarInstancia(std::string& nomeInstancia, Data& data);

void carregarInstanciaSetup(std::string& nomeInstanciaSetup, DataSetup& data);

#endif // LEITORINSTANCIA_H_INCLUDED

