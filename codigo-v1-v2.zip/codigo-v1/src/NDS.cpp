#include "NDS.h"

void Dominate(std::vector<Results>& All_Solution) {

    //cout << "makespan" << "   " << "energia" << endl;
    /*for (int z = 0; z < All_Solution.size(); z++) {
        cout << All_Solution[z].makespan <<"     " << All_Solution[z].energia << endl;
    }*/
    //cout << "\nQuantidade de solucoes: " << All_Solution.size() << endl;

    //cout << "\n\n\nApagando solucoes iguais:" << "\n";

    for (int x = 0; x < All_Solution.size(); x++) {
        for (int y = 0; y < All_Solution.size(); y++) {
            if (x == y) {
                continue;
            }
            if (abs(All_Solution[x].makespan - All_Solution[y].makespan) < 0.000001 && abs(All_Solution[x].energia - All_Solution[y].energia) < 0.000001) {
                All_Solution.erase(All_Solution.begin() + y);
                y--;
            }
        }
    }

    /*cout << "makespan" << "   " << "energia" << endl;
    for (int z = 0; z < All_Solution.size(); z++) {
        cout << All_Solution[z].makespan << "     " << All_Solution[z].energia << endl;
    }

    cout << "\nQuantidade de solucoes: " << All_Solution.size() << endl;*/

    //ordena��o das solucoes crescente pelo makespan

    for (int i = 0; i < All_Solution.size(); i++) {
        for (int j = 0; j < All_Solution.size(); j++) {

            if (All_Solution[i].makespan - All_Solution[j].makespan < 0.000001) {

                Results aux = All_Solution[i];
                All_Solution[i] = All_Solution[j];
                All_Solution[j] = aux;
            }
        }
    }

    //cout << "\nOrdenando em ordem crescente as solucoes pelo makespan: " << endl;

    /*cout << "makespan" << "   " << "energia" << endl;
    for (int z = 0; z < All_Solution.size(); z++) {
        cout << All_Solution[z].makespan << "     " << All_Solution[z].energia << endl;
    }*/

    //apagando solucoes dominadas:

    for (int x = 0; x < All_Solution.size(); x++) {
        for (int y = 0; y < All_Solution.size(); y++) {

            float teste_makespan = All_Solution[x].makespan - All_Solution[y].makespan;
            float teste_energia = All_Solution[x].energia - All_Solution[y].energia;

            if (x != y && teste_makespan < 0.05 && teste_energia < 0.05) {
                All_Solution.erase(All_Solution.begin() + y);
                y--;
            }
        }
    }
}


bool dominantes(float a1, float b1, float a2, float b2) {
    if ((a1 <= a2 && b1 < b2) || (a1 < a2 && b1 <= b2)) return true;
    else return false;
}