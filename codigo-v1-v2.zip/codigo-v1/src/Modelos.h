#ifndef MODELOS_H_INCLUDED
#define MODELOS_H_INCLUDED

#include <iostream>
#include <string>
#include <algorithm>
#include <fstream>

#include "LeitorInstancia.h"
#include "ConstrutivoSetup.h"
#include "localSearch.h"
#include "ConstrutivoRandom.h"
#include "Timer.h"
#include "Vizinhancas_FI.h"
#include "metricas.h"
#include "NDS.h"
#include "Resultado.h"

pair<float,float> NEH_Swap(string instancia, string modelo);
pair<float,float> NEH_Swap_modifRK(string instancia, string modelo);

void NEH_Swap_energy_saving(string instancia, string modelo, pair<float,float> nadir_point);

void NEH_Swap_2fase_energy_saving(string instancia, string modelo, pair<float, float> nadir_point);

void NEH_Swap_energy_saving_2fase_energy_saving(string instancia, string modelo, pair<float, float> nadir_point);

void NEH_VND_energy_saving(string instancia, string modelo, pair<float,float> nadir_point);
void NEH_VND_energy_saving_modifRK(string instancia, string modelo, pair<float,float> nadir_point);

void NEH_VND_2fase_energy_saving(string instancia, string modelo, pair<float, float> nadir_point);

void NEH_VND_energy_saving_2fase_energy_saving(string instancia, string modelo, pair<float, float> nadir_point);



#endif // MODELOS_H_INCLUDED
