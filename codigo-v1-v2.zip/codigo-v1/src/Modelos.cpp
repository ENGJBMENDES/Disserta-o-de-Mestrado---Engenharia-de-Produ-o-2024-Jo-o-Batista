using namespace std;

#include "Modelos.h"

pair<float,float> NEH_Swap(string instancia, string modelo) {

    Timer timer;
    timer.start();

    string nomeInstanciaSetup = instancia;
    cout << "\n";
    cout << nomeInstanciaSetup << endl;
    cout << "\n";

    DataSetup dataSetup;
    carregarInstanciaSetup(nomeInstanciaSetup, dataSetup);


    // defini��o matriz de velocidades
    int nivel_velocidade = 2;
    vector<vector<int>> matriz_vel_teste;

    matriz_vel_teste.resize(dataSetup.n);
    for (int i = 0; i < dataSetup.n; i++) {
        matriz_vel_teste[i].resize(dataSetup.m);
    }

    vector<Results> All_Solution;

    //cout << "Matriz de velocidade inicial: "<< nivel_velocidade << "\n" << endl;
    for (int i = 0; i < dataSetup.n; i++) {
        for (int j = 0; j < dataSetup.m; j++) {
            matriz_vel_teste[i][j] = nivel_velocidade;
            //cout << matriz_vel_teste[i][j] << "\t";
        }
        //cout << "\n";
    }

    //cout << "\n\nConstrutivo NEH" << endl;
    Results Solucao_NEH = execute_construtivoSetup_NEHTRB(dataSetup, matriz_vel_teste);
    All_Solution.push_back(Solucao_NEH);


    //NEH com VND
    Results Solucao_Swap = Swap_local_search(Solucao_NEH.sequence, dataSetup, Solucao_NEH.makespan, matriz_vel_teste);
    All_Solution.push_back(Solucao_Swap);

    //cout << Solucao_VND.makespan << "\t" << Solucao_VND.energia << endl;

    //Results Solucao_energy_saving = energy_saving_adaptado(dataSetup, Solucao_Swap.sequence, matriz_vel_teste, Solucao_Swap.makespan, Solucao_Swap.energia);
    //All_Solution.push_back(Solucao_energy_saving);

    //cout << Solucao_energy_saving.makespan << "\t" << Solucao_energy_saving.energia << endl;
    //cout << "*********************************" << endl;

    bool teste = true;
    vector<vector<float>> p_atualizado;
    p_atualizado.resize(dataSetup.n);
    for (int i = 0; i < dataSetup.n; i++) {
        p_atualizado[i].resize(dataSetup.m);
    }
    float min_value = std::numeric_limits<float>::max();  // Valor inicial m�ximo poss�vel
    int min_row = -1;
    int min_col = -1;

    while (teste == true) {

        teste = false;

        for (int i = 0; i < dataSetup.n; i++) {
            for (int j = 0; j < dataSetup.m; j++) {
                p_atualizado[i][j] = dataSetup.p[i][j] / dataSetup.speed[j][matriz_vel_teste[i][j]];
            }
        }

        for (int i = 0; i < dataSetup.n; i++) {
            for (int j = 0; j < dataSetup.m; j++) {
                if (p_atualizado[i][j] < min_value && matriz_vel_teste[i][j] > 0) {
                    min_value = p_atualizado[i][j];
                    min_row = i;
                    min_col = j;
                    teste = true;
                }
            }
        }

        if (matriz_vel_teste[min_row][min_col] > 0) {
            matriz_vel_teste[min_row][min_col]--;
        }

        //cout << "\n\nConstrutivo NEH" << endl;
        Solucao_NEH = execute_construtivoSetup_NEHTRB(dataSetup, matriz_vel_teste);
        All_Solution.push_back(Solucao_NEH);

        //NEH com VND
        Solucao_Swap = Swap_local_search(Solucao_NEH.sequence, dataSetup, Solucao_NEH.makespan, matriz_vel_teste);
        All_Solution.push_back(Solucao_Swap);

        //Results Solucao_energy_saving = energy_saving_adaptado(dataSetup, Solucao_Swap.sequence, Solucao_Swap.matriz_velocidade, Solucao_Swap.makespan, Solucao_Swap.energia);
        //All_Solution.push_back(Solucao_energy_saving);

        min_value = std::numeric_limits<float>::max();
    }

    Dominate(All_Solution);

    //segunda_fase(All_Solution, dataSetup);

    //Dominate(All_Solution);

    double CPU_Time = timer.stop();

    // Calculating total time taken by the program.
    std::cout.precision(5);
    cout << "CPU TIME: " << fixed << CPU_Time;
    cout << " sec " << endl;
    //***********************************FIM**************************************************************

    cout << "\nSolucoes nao dominadas: " << endl;

    cout << "makespan" << "   " << "energia" << endl;
    for (int z = 0; z < All_Solution.size(); z++) {
        cout << All_Solution[z].makespan << "     " << All_Solution[z].energia << endl;
    }

    pair <float, float> nadir_point;
    nadir_point.first = 1.1 * All_Solution.back().makespan;
    //cout << nadir_point.first << endl;
    nadir_point.second = 1.1 * All_Solution.front().energia;
    //cout << nadir_point.second << endl;

    float hipervolume = hypervolume(All_Solution, nadir_point);

    // salvando makespan e energia das solu��es n�o dominadas em arquivo pra pareto front

    escrever_nds(All_Solution, nomeInstanciaSetup, modelo);

    //resumo de metricas

    escrever_resumo(All_Solution, nomeInstanciaSetup, CPU_Time, hipervolume, modelo);

    //salvando solu��es n�o dominadas em arquivo

    escrever_solucao_completa(All_Solution, nomeInstanciaSetup, CPU_Time, hipervolume, dataSetup, modelo);

    return nadir_point;
}



void NEH_Swap_energy_saving(string instancia, string modelo, pair<float,float> nadir_point) {

    Timer timer;
    timer.start();

    string nomeInstanciaSetup = instancia;
    cout << "\n";
    cout << nomeInstanciaSetup << endl;
    cout << "\n";

    DataSetup dataSetup;
    carregarInstanciaSetup(nomeInstanciaSetup, dataSetup);


    // defini��o matriz de velocidades
    int nivel_velocidade = 2;
    vector<vector<int>> matriz_vel_teste;

    matriz_vel_teste.resize(dataSetup.n);
    for (int i = 0; i < dataSetup.n; i++) {
        matriz_vel_teste[i].resize(dataSetup.m);
    }

    vector<Results> All_Solution;

    //cout << "Matriz de velocidade inicial: "<< nivel_velocidade << "\n" << endl;
    for (int i = 0; i < dataSetup.n; i++) {
        for (int j = 0; j < dataSetup.m; j++) {
            matriz_vel_teste[i][j] = nivel_velocidade;
            //cout << matriz_vel_teste[i][j] << "\t";
        }
        //cout << "\n";
    }

    //cout << "\n\nConstrutivo NEH" << endl;
    Results Solucao_NEH = execute_construtivoSetup_NEHTRB(dataSetup, matriz_vel_teste);
    All_Solution.push_back(Solucao_NEH);


    //NEH com VND
    Results Solucao_Swap = Swap_local_search(Solucao_NEH.sequence, dataSetup, Solucao_NEH.makespan, matriz_vel_teste);
    All_Solution.push_back(Solucao_Swap);

    //cout << Solucao_VND.makespan << "\t" << Solucao_VND.energia << endl;

    Results Solucao_energy_saving = energy_saving_adaptado(dataSetup, Solucao_Swap.sequence, matriz_vel_teste, Solucao_Swap.makespan, Solucao_Swap.energia);
    All_Solution.push_back(Solucao_energy_saving);

    //cout << Solucao_energy_saving.makespan << "\t" << Solucao_energy_saving.energia << endl;
    //cout << "*********************************" << endl;

    bool teste = true;
    vector<vector<float>> p_atualizado;
    p_atualizado.resize(dataSetup.n);
    for (int i = 0; i < dataSetup.n; i++) {
        p_atualizado[i].resize(dataSetup.m);
    }
    float min_value = std::numeric_limits<float>::max();  // Valor inicial m�ximo poss�vel
    int min_row = -1;
    int min_col = -1;

    while (teste == true) {

        teste = false;

        for (int i = 0; i < dataSetup.n; i++) {
            for (int j = 0; j < dataSetup.m; j++) {
                p_atualizado[i][j] = dataSetup.p[i][j] / dataSetup.speed[j][matriz_vel_teste[i][j]];
            }
        }

        for (int i = 0; i < dataSetup.n; i++) {
            for (int j = 0; j < dataSetup.m; j++) {
                if (p_atualizado[i][j] < min_value && matriz_vel_teste[i][j] > 0) {
                    min_value = p_atualizado[i][j];
                    min_row = i;
                    min_col = j;
                    teste = true;
                }
            }
        }

        if (matriz_vel_teste[min_row][min_col] > 0) {
            matriz_vel_teste[min_row][min_col]--;
        }

        //cout << "\n\nConstrutivo NEH" << endl;
        Solucao_NEH = execute_construtivoSetup_NEHTRB(dataSetup, matriz_vel_teste);
        All_Solution.push_back(Solucao_NEH);

        //NEH com VND
        Solucao_Swap = Swap_local_search(Solucao_NEH.sequence, dataSetup, Solucao_NEH.makespan, matriz_vel_teste);
        All_Solution.push_back(Solucao_Swap);

        Solucao_energy_saving = energy_saving_adaptado(dataSetup, Solucao_Swap.sequence, Solucao_Swap.matriz_velocidade, Solucao_Swap.makespan, Solucao_Swap.energia);
        All_Solution.push_back(Solucao_energy_saving);

        min_value = std::numeric_limits<float>::max();
    }

    Dominate(All_Solution);

    //segunda_fase(All_Solution, dataSetup);

    //Dominate(All_Solution);

    double CPU_Time = timer.stop();

    // Calculating total time taken by the program.
    std::cout.precision(5);
    cout << "CPU TIME: " << fixed << CPU_Time;
    cout << " sec " << endl;
    //***********************************FIM**************************************************************

    cout << "\nSolucoes nao dominadas: " << endl;

    cout << "makespan" << "   " << "energia" << endl;
    for (int z = 0; z < All_Solution.size(); z++) {
        cout << All_Solution[z].makespan << "     " << All_Solution[z].energia << endl;
    }

    //pair <float, float> nadir_point;
    //nadir_point.first = 1.1 * All_Solution.back().makespan;
    //cout << nadir_point.first << endl;
    //nadir_point.second = 1.1 * All_Solution.front().energia;
    //cout << nadir_point.second << endl;

    float hipervolume = hypervolume(All_Solution, nadir_point);

    // salvando makespan e energia das solu��es n�o dominadas em arquivo pra pareto front

    escrever_nds(All_Solution, nomeInstanciaSetup, modelo);

    //resumo de metricas

    escrever_resumo(All_Solution, nomeInstanciaSetup, CPU_Time, hipervolume, modelo);

    //salvando solu��es n�o dominadas em arquivo

    escrever_solucao_completa(All_Solution, nomeInstanciaSetup, CPU_Time, hipervolume, dataSetup, modelo);

}





void NEH_Swap_energy_saving_2fase_energy_saving(string instancia, string modelo, pair<float, float> nadir_point) {

    Timer timer;
    timer.start();

    string nomeInstanciaSetup = instancia;
    cout << "\n";
    cout << nomeInstanciaSetup << endl;
    cout << "\n";

    DataSetup dataSetup;
    carregarInstanciaSetup(nomeInstanciaSetup, dataSetup);


    // defini��o matriz de velocidades
    int nivel_velocidade = 2;
    vector<vector<int>> matriz_vel_teste;

    matriz_vel_teste.resize(dataSetup.n);
    for (int i = 0; i < dataSetup.n; i++) {
        matriz_vel_teste[i].resize(dataSetup.m);
    }

    vector<Results> All_Solution;

    //cout << "Matriz de velocidade inicial: "<< nivel_velocidade << "\n" << endl;
    for (int i = 0; i < dataSetup.n; i++) {
        for (int j = 0; j < dataSetup.m; j++) {
            matriz_vel_teste[i][j] = nivel_velocidade;
            //cout << matriz_vel_teste[i][j] << "\t";
        }
        //cout << "\n";
    }

    //cout << "\n\nConstrutivo NEH" << endl;
    Results Solucao_NEH = execute_construtivoSetup_NEHTRB(dataSetup, matriz_vel_teste);
    All_Solution.push_back(Solucao_NEH);


    //NEH com VND
    Results Solucao_Swap = Swap_local_search(Solucao_NEH.sequence, dataSetup, Solucao_NEH.makespan, matriz_vel_teste);
    All_Solution.push_back(Solucao_Swap);

    //cout << Solucao_VND.makespan << "\t" << Solucao_VND.energia << endl;

    Results Solucao_energy_saving = energy_saving_adaptado(dataSetup, Solucao_Swap.sequence, matriz_vel_teste, Solucao_Swap.makespan, Solucao_Swap.energia);
    All_Solution.push_back(Solucao_energy_saving);

    //cout << Solucao_energy_saving.makespan << "\t" << Solucao_energy_saving.energia << endl;
    //cout << "*********************************" << endl;

    bool teste = true;
    vector<vector<float>> p_atualizado;
    p_atualizado.resize(dataSetup.n);
    for (int i = 0; i < dataSetup.n; i++) {
        p_atualizado[i].resize(dataSetup.m);
    }
    float min_value = std::numeric_limits<float>::max();  // Valor inicial m�ximo poss�vel
    int min_row = -1;
    int min_col = -1;

    while (teste == true) {

        teste = false;

        for (int i = 0; i < dataSetup.n; i++) {
            for (int j = 0; j < dataSetup.m; j++) {
                p_atualizado[i][j] = dataSetup.p[i][j] / dataSetup.speed[j][matriz_vel_teste[i][j]];
            }
        }

        for (int i = 0; i < dataSetup.n; i++) {
            for (int j = 0; j < dataSetup.m; j++) {
                if (p_atualizado[i][j] < min_value && matriz_vel_teste[i][j] > 0) {
                    min_value = p_atualizado[i][j];
                    min_row = i;
                    min_col = j;
                    teste = true;
                }
            }
        }

        if (matriz_vel_teste[min_row][min_col] > 0) {
            matriz_vel_teste[min_row][min_col]--;
        }

        //cout << "\n\nConstrutivo NEH" << endl;
        Solucao_NEH = execute_construtivoSetup_NEHTRB(dataSetup, matriz_vel_teste);
        All_Solution.push_back(Solucao_NEH);

        //NEH com VND
        Solucao_Swap = Swap_local_search(Solucao_NEH.sequence, dataSetup, Solucao_NEH.makespan, matriz_vel_teste);
        All_Solution.push_back(Solucao_Swap);

        Solucao_energy_saving = energy_saving_adaptado(dataSetup, Solucao_Swap.sequence, Solucao_Swap.matriz_velocidade, Solucao_Swap.makespan, Solucao_Swap.energia);
        All_Solution.push_back(Solucao_energy_saving);

        min_value = std::numeric_limits<float>::max();
    }

    Dominate(All_Solution);

    segunda_fase(All_Solution, dataSetup);

    Dominate(All_Solution);

    double CPU_Time = timer.stop();

    // Calculating total time taken by the program.
    std::cout.precision(5);
    cout << "CPU TIME: " << fixed << CPU_Time;
    cout << " sec " << endl;
    //***********************************FIM**************************************************************

    cout << "\nSolucoes nao dominadas: " << endl;

    cout << "makespan" << "   " << "energia" << endl;
    for (int z = 0; z < All_Solution.size(); z++) {
        cout << All_Solution[z].makespan << "     " << All_Solution[z].energia << endl;
    }

    //pair <float, float> nadir_point;
    //nadir_point.first = 1.1 * All_Solution.back().makespan;
    //cout << nadir_point.first << endl;
    //nadir_point.second = 1.1 * All_Solution.front().energia;
    //cout << nadir_point.second << endl;

    float hipervolume = hypervolume(All_Solution, nadir_point);

    // salvando makespan e energia das solu��es n�o dominadas em arquivo pra pareto front

    escrever_nds(All_Solution, nomeInstanciaSetup, modelo);

    //resumo de metricas

    escrever_resumo(All_Solution, nomeInstanciaSetup, CPU_Time, hipervolume, modelo);

    //salvando solu��es n�o dominadas em arquivo

    escrever_solucao_completa(All_Solution, nomeInstanciaSetup, CPU_Time, hipervolume, dataSetup, modelo);

}





void NEH_Swap_2fase_energy_saving(string instancia, string modelo, pair<float, float> nadir_point) {

    Timer timer;
    timer.start();

    string nomeInstanciaSetup = instancia;
    cout << "\n";
    cout << nomeInstanciaSetup << endl;
    cout << "\n";

    DataSetup dataSetup;
    carregarInstanciaSetup(nomeInstanciaSetup, dataSetup);


    // defini��o matriz de velocidades
    int nivel_velocidade = 2;
    vector<vector<int>> matriz_vel_teste;

    matriz_vel_teste.resize(dataSetup.n);
    for (int i = 0; i < dataSetup.n; i++) {
        matriz_vel_teste[i].resize(dataSetup.m);
    }

    vector<Results> All_Solution;

    //cout << "Matriz de velocidade inicial: "<< nivel_velocidade << "\n" << endl;
    for (int i = 0; i < dataSetup.n; i++) {
        for (int j = 0; j < dataSetup.m; j++) {
            matriz_vel_teste[i][j] = nivel_velocidade;
            //cout << matriz_vel_teste[i][j] << "\t";
        }
        //cout << "\n";
    }

    //cout << "\n\nConstrutivo NEH" << endl;
    Results Solucao_NEH = execute_construtivoSetup_NEHTRB(dataSetup, matriz_vel_teste);
    All_Solution.push_back(Solucao_NEH);


    //NEH com VND
    Results Solucao_Swap = Swap_local_search(Solucao_NEH.sequence, dataSetup, Solucao_NEH.makespan, matriz_vel_teste);
    All_Solution.push_back(Solucao_Swap);

    //cout << Solucao_VND.makespan << "\t" << Solucao_VND.energia << endl;

    //Results Solucao_energy_saving = energy_saving_adaptado(dataSetup, Solucao_Swap.sequence, matriz_vel_teste, Solucao_Swap.makespan, Solucao_Swap.energia);
    //All_Solution.push_back(Solucao_energy_saving);

    //cout << Solucao_energy_saving.makespan << "\t" << Solucao_energy_saving.energia << endl;
    //cout << "*********************************" << endl;

    bool teste = true;
    vector<vector<float>> p_atualizado;
    p_atualizado.resize(dataSetup.n);
    for (int i = 0; i < dataSetup.n; i++) {
        p_atualizado[i].resize(dataSetup.m);
    }
    float min_value = std::numeric_limits<float>::max();  // Valor inicial m�ximo poss�vel
    int min_row = -1;
    int min_col = -1;

    while (teste == true) {

        teste = false;

        for (int i = 0; i < dataSetup.n; i++) {
            for (int j = 0; j < dataSetup.m; j++) {
                p_atualizado[i][j] = dataSetup.p[i][j] / dataSetup.speed[j][matriz_vel_teste[i][j]];
            }
        }

        for (int i = 0; i < dataSetup.n; i++) {
            for (int j = 0; j < dataSetup.m; j++) {
                if (p_atualizado[i][j] < min_value && matriz_vel_teste[i][j] > 0) {
                    min_value = p_atualizado[i][j];
                    min_row = i;
                    min_col = j;
                    teste = true;
                }
            }
        }

        if (matriz_vel_teste[min_row][min_col] > 0) {
            matriz_vel_teste[min_row][min_col]--;
        }

        //cout << "\n\nConstrutivo NEH" << endl;
        Solucao_NEH = execute_construtivoSetup_NEHTRB(dataSetup, matriz_vel_teste);
        All_Solution.push_back(Solucao_NEH);

        //NEH com VND
        Solucao_Swap = Swap_local_search(Solucao_NEH.sequence, dataSetup, Solucao_NEH.makespan, matriz_vel_teste);
        All_Solution.push_back(Solucao_Swap);

        //Solucao_energy_saving = energy_saving_adaptado(dataSetup, Solucao_Swap.sequence, Solucao_Swap.matriz_velocidade, Solucao_Swap.makespan, Solucao_Swap.energia);
        //All_Solution.push_back(Solucao_energy_saving);

        min_value = std::numeric_limits<float>::max();
    }

    Dominate(All_Solution);

    segunda_fase(All_Solution, dataSetup);

    Dominate(All_Solution);

    double CPU_Time = timer.stop();

    // Calculating total time taken by the program.
    std::cout.precision(5);
    cout << "CPU TIME: " << fixed << CPU_Time;
    cout << " sec " << endl;
    //***********************************FIM**************************************************************

    cout << "\nSolucoes nao dominadas: " << endl;

    cout << "makespan" << "   " << "energia" << endl;
    for (int z = 0; z < All_Solution.size(); z++) {
        cout << All_Solution[z].makespan << "     " << All_Solution[z].energia << endl;
    }

    //pair <float, float> nadir_point;
    //nadir_point.first = 1.1 * All_Solution.back().makespan;
    //cout << nadir_point.first << endl;
    //nadir_point.second = 1.1 * All_Solution.front().energia;
    //cout << nadir_point.second << endl;

    float hipervolume = hypervolume(All_Solution, nadir_point);

    // salvando makespan e energia das solu��es n�o dominadas em arquivo pra pareto front

    escrever_nds(All_Solution, nomeInstanciaSetup, modelo);

    //resumo de metricas

    escrever_resumo(All_Solution, nomeInstanciaSetup, CPU_Time, hipervolume, modelo);

    //salvando solu��es n�o dominadas em arquivo

    escrever_solucao_completa(All_Solution, nomeInstanciaSetup, CPU_Time, hipervolume, dataSetup, modelo);

}



void NEH_VND_energy_saving(string instancia, string modelo, pair<float,float> nadir_point) {

    Timer timer;
    timer.start();

    string nomeInstanciaSetup = instancia;
    cout << "\n";
    cout << nomeInstanciaSetup << endl;
    cout << "\n";

    DataSetup dataSetup;
    carregarInstanciaSetup(nomeInstanciaSetup, dataSetup);


    // defini��o matriz de velocidades
    int nivel_velocidade = 2;
    vector<vector<int>> matriz_vel_teste;

    matriz_vel_teste.resize(dataSetup.n);
    for (int i = 0; i < dataSetup.n; i++) {
        matriz_vel_teste[i].resize(dataSetup.m);
    }

    vector<Results> All_Solution;

    //cout << "Matriz de velocidade inicial: "<< nivel_velocidade << "\n" << endl;
    for (int i = 0; i < dataSetup.n; i++) {
        for (int j = 0; j < dataSetup.m; j++) {
            matriz_vel_teste[i][j] = nivel_velocidade;
            //cout << matriz_vel_teste[i][j] << "\t";
        }
        //cout << "\n";
    }

    //cout << "\n\nConstrutivo NEH" << endl;
    Results Solucao_NEH = execute_construtivoSetup_NEHTRB(dataSetup, matriz_vel_teste);
    All_Solution.push_back(Solucao_NEH);


    //NEH com VND
    Results Solucao_VND = VND_local_search(Solucao_NEH.sequence, dataSetup, Solucao_NEH.makespan, matriz_vel_teste);
    All_Solution.push_back(Solucao_VND);

    //cout << Solucao_VND.makespan << "\t" << Solucao_VND.energia << endl;

    Results Solucao_energy_saving = energy_saving_adaptado(dataSetup, Solucao_VND.sequence, matriz_vel_teste, Solucao_VND.makespan, Solucao_VND.energia);
    All_Solution.push_back(Solucao_energy_saving);

    //cout << Solucao_energy_saving.makespan << "\t" << Solucao_energy_saving.energia << endl;
    //cout << "*********************************" << endl;

    bool teste = true;
    vector<vector<float>> p_atualizado;
    p_atualizado.resize(dataSetup.n);
    for (int i = 0; i < dataSetup.n; i++) {
        p_atualizado[i].resize(dataSetup.m);
    }
    float min_value = std::numeric_limits<float>::max();  // Valor inicial m�ximo poss�vel
    int min_row = -1;
    int min_col = -1;

    while (teste == true) {

        teste = false;

        for (int i = 0; i < dataSetup.n; i++) {
            for (int j = 0; j < dataSetup.m; j++) {
                p_atualizado[i][j] = dataSetup.p[i][j] / dataSetup.speed[j][matriz_vel_teste[i][j]];
            }
        }

        for (int i = 0; i < dataSetup.n; i++) {
            for (int j = 0; j < dataSetup.m; j++) {
                if (p_atualizado[i][j] < min_value && matriz_vel_teste[i][j] > 0) {
                    min_value = p_atualizado[i][j];
                    min_row = i;
                    min_col = j;
                    teste = true;
                }
            }
        }

        if (matriz_vel_teste[min_row][min_col] > 0) {
            matriz_vel_teste[min_row][min_col]--;
        }

        //cout << "\n\nConstrutivo NEH" << endl;
        Solucao_NEH = execute_construtivoSetup_NEHTRB(dataSetup, matriz_vel_teste);
        All_Solution.push_back(Solucao_NEH);

        //NEH com VND
        Solucao_VND = VND_local_search(Solucao_NEH.sequence, dataSetup, Solucao_NEH.makespan, matriz_vel_teste);
        All_Solution.push_back(Solucao_VND);

        Solucao_energy_saving = energy_saving_adaptado(dataSetup, Solucao_VND.sequence, Solucao_VND.matriz_velocidade, Solucao_VND.makespan, Solucao_VND.energia);
        All_Solution.push_back(Solucao_energy_saving);

        min_value = std::numeric_limits<float>::max();
    }

    Dominate(All_Solution);

    //segunda_fase(All_Solution, dataSetup);

    //Dominate(All_Solution);

    double CPU_Time = timer.stop();

    // Calculating total time taken by the program.
    std::cout.precision(5);
    cout << "CPU TIME: " << fixed << CPU_Time;
    cout << " sec " << endl;
    //***********************************FIM**************************************************************

    cout << "\nSolucoes nao dominadas: " << endl;

    cout << "makespan" << "   " << "energia" << endl;
    for (int z = 0; z < All_Solution.size(); z++) {
        cout << All_Solution[z].makespan << "     " << All_Solution[z].energia << endl;
    }

    //pair <float, float> nadir_point;
    //nadir_point.first = 1.1 * All_Solution.back().makespan;
    //cout << nadir_point.first << endl;
    //nadir_point.second = 1.1 * All_Solution.front().energia;
    //cout << nadir_point.second << endl;

    float hipervolume = hypervolume(All_Solution, nadir_point);

    // salvando makespan e energia das solu��es n�o dominadas em arquivo pra pareto front

    escrever_nds(All_Solution, nomeInstanciaSetup, modelo);

    //resumo de metricas

    escrever_resumo(All_Solution, nomeInstanciaSetup, CPU_Time, hipervolume, modelo);

    //salvando solu��es n�o dominadas em arquivo

    escrever_solucao_completa(All_Solution, nomeInstanciaSetup, CPU_Time, hipervolume, dataSetup, modelo);

}


void NEH_VND_2fase_energy_saving(string instancia, string modelo, pair<float, float> nadir_point) {

    Timer timer;
    timer.start();

    string nomeInstanciaSetup = instancia;
    cout << "\n";
    cout << nomeInstanciaSetup << endl;
    cout << "\n";

    DataSetup dataSetup;
    carregarInstanciaSetup(nomeInstanciaSetup, dataSetup);


    // defini��o matriz de velocidades
    int nivel_velocidade = 2;
    vector<vector<int>> matriz_vel_teste;

    matriz_vel_teste.resize(dataSetup.n);
    for (int i = 0; i < dataSetup.n; i++) {
        matriz_vel_teste[i].resize(dataSetup.m);
    }

    vector<Results> All_Solution;

    //cout << "Matriz de velocidade inicial: "<< nivel_velocidade << "\n" << endl;
    for (int i = 0; i < dataSetup.n; i++) {
        for (int j = 0; j < dataSetup.m; j++) {
            matriz_vel_teste[i][j] = nivel_velocidade;
            //cout << matriz_vel_teste[i][j] << "\t";
        }
        //cout << "\n";
    }

    //cout << "\n\nConstrutivo NEH" << endl;
    Results Solucao_NEH = execute_construtivoSetup_NEHTRB(dataSetup, matriz_vel_teste);
    All_Solution.push_back(Solucao_NEH);


    //NEH com VND
    Results Solucao_VND = VND_local_search(Solucao_NEH.sequence, dataSetup, Solucao_NEH.makespan, matriz_vel_teste);
    All_Solution.push_back(Solucao_VND);

    //cout << Solucao_VND.makespan << "\t" << Solucao_VND.energia << endl;

    //Results Solucao_energy_saving = energy_saving_adaptado(dataSetup, Solucao_VND.sequence, matriz_vel_teste, Solucao_VND.makespan, Solucao_VND.energia);
    //All_Solution.push_back(Solucao_energy_saving);

    //cout << Solucao_energy_saving.makespan << "\t" << Solucao_energy_saving.energia << endl;
    //cout << "*********************************" << endl;

    bool teste = true;
    vector<vector<float>> p_atualizado;
    p_atualizado.resize(dataSetup.n);
    for (int i = 0; i < dataSetup.n; i++) {
        p_atualizado[i].resize(dataSetup.m);
    }
    float min_value = std::numeric_limits<float>::max();  // Valor inicial m�ximo poss�vel
    int min_row = -1;
    int min_col = -1;

    while (teste == true) {

        teste = false;

        for (int i = 0; i < dataSetup.n; i++) {
            for (int j = 0; j < dataSetup.m; j++) {
                p_atualizado[i][j] = dataSetup.p[i][j] / dataSetup.speed[j][matriz_vel_teste[i][j]];
            }
        }

        for (int i = 0; i < dataSetup.n; i++) {
            for (int j = 0; j < dataSetup.m; j++) {
                if (p_atualizado[i][j] < min_value && matriz_vel_teste[i][j] > 0) {
                    min_value = p_atualizado[i][j];
                    min_row = i;
                    min_col = j;
                    teste = true;
                }
            }
        }

        if (matriz_vel_teste[min_row][min_col] > 0) {
            matriz_vel_teste[min_row][min_col]--;
        }

        //cout << "\n\nConstrutivo NEH" << endl;
        Solucao_NEH = execute_construtivoSetup_NEHTRB(dataSetup, matriz_vel_teste);
        All_Solution.push_back(Solucao_NEH);

        //NEH com VND
        Solucao_VND = VND_local_search(Solucao_NEH.sequence, dataSetup, Solucao_NEH.makespan, matriz_vel_teste);
        All_Solution.push_back(Solucao_VND);

        //Solucao_energy_saving = energy_saving_adaptado(dataSetup, Solucao_VND.sequence, Solucao_VND.matriz_velocidade, Solucao_VND.makespan, Solucao_VND.energia);
        //All_Solution.push_back(Solucao_energy_saving);

        min_value = std::numeric_limits<float>::max();
    }

    Dominate(All_Solution);

    segunda_fase(All_Solution, dataSetup);

    Dominate(All_Solution);

    double CPU_Time = timer.stop();

    // Calculating total time taken by the program.
    std::cout.precision(5);
    cout << "CPU TIME: " << fixed << CPU_Time;
    cout << " sec " << endl;
    //***********************************FIM**************************************************************

    cout << "\nSolucoes nao dominadas: " << endl;

    cout << "makespan" << "   " << "energia" << endl;
    for (int z = 0; z < All_Solution.size(); z++) {
        cout << All_Solution[z].makespan << "     " << All_Solution[z].energia << endl;
    }

    //pair <float, float> nadir_point;
    //nadir_point.first = 1.1 * All_Solution.back().makespan;
    //cout << nadir_point.first << endl;
    //nadir_point.second = 1.1 * All_Solution.front().energia;
    //cout << nadir_point.second << endl;

    float hipervolume = hypervolume(All_Solution, nadir_point);

    // salvando makespan e energia das solu��es n�o dominadas em arquivo pra pareto front

    escrever_nds(All_Solution, nomeInstanciaSetup, modelo);

    //resumo de metricas

    escrever_resumo(All_Solution, nomeInstanciaSetup, CPU_Time, hipervolume, modelo);

    //salvando solu��es n�o dominadas em arquivo

    escrever_solucao_completa(All_Solution, nomeInstanciaSetup, CPU_Time, hipervolume, dataSetup, modelo);

}


void NEH_VND_energy_saving_2fase_energy_saving(string instancia, string modelo, pair<float, float> nadir_point) {

    Timer timer;
    timer.start();

    string nomeInstanciaSetup = instancia;
    cout << "\n";
    cout << nomeInstanciaSetup << endl;
    cout << "\n";

    DataSetup dataSetup;
    carregarInstanciaSetup(nomeInstanciaSetup, dataSetup);


    // defini��o matriz de velocidades
    int nivel_velocidade = 2;
    vector<vector<int>> matriz_vel_teste;

    matriz_vel_teste.resize(dataSetup.n);
    for (int i = 0; i < dataSetup.n; i++) {
        matriz_vel_teste[i].resize(dataSetup.m);
    }

    vector<Results> All_Solution;

    //cout << "Matriz de velocidade inicial: "<< nivel_velocidade << "\n" << endl;
    for (int i = 0; i < dataSetup.n; i++) {
        for (int j = 0; j < dataSetup.m; j++) {
            matriz_vel_teste[i][j] = nivel_velocidade;
            //cout << matriz_vel_teste[i][j] << "\t";
        }
        //cout << "\n";
    }

    //cout << "\n\nConstrutivo NEH" << endl;
    Results Solucao_NEH = execute_construtivoSetup_NEHTRB(dataSetup, matriz_vel_teste);
    All_Solution.push_back(Solucao_NEH);


    //NEH com VND
    Results Solucao_VND = VND_local_search(Solucao_NEH.sequence, dataSetup, Solucao_NEH.makespan, matriz_vel_teste);
    All_Solution.push_back(Solucao_VND);

    //cout << Solucao_VND.makespan << "\t" << Solucao_VND.energia << endl;

    Results Solucao_energy_saving = energy_saving_adaptado(dataSetup, Solucao_VND.sequence, matriz_vel_teste, Solucao_VND.makespan, Solucao_VND.energia);
    All_Solution.push_back(Solucao_energy_saving);

    //cout << Solucao_energy_saving.makespan << "\t" << Solucao_energy_saving.energia << endl;
    //cout << "*********************************" << endl;

    bool teste = true;
    vector<vector<float>> p_atualizado;
    p_atualizado.resize(dataSetup.n);
    for (int i = 0; i < dataSetup.n; i++) {
        p_atualizado[i].resize(dataSetup.m);
    }
    float min_value = std::numeric_limits<float>::max();  // Valor inicial m�ximo poss�vel
    int min_row = -1;
    int min_col = -1;

    while (teste == true) {

        teste = false;

        for (int i = 0; i < dataSetup.n; i++) {
            for (int j = 0; j < dataSetup.m; j++) {
                p_atualizado[i][j] = dataSetup.p[i][j] / dataSetup.speed[j][matriz_vel_teste[i][j]];
            }
        }

        for (int i = 0; i < dataSetup.n; i++) {
            for (int j = 0; j < dataSetup.m; j++) {
                if (p_atualizado[i][j] < min_value && matriz_vel_teste[i][j] > 0) {
                    min_value = p_atualizado[i][j];
                    min_row = i;
                    min_col = j;
                    teste = true;
                }
            }
        }

        if (matriz_vel_teste[min_row][min_col] > 0) {
            matriz_vel_teste[min_row][min_col]--;
        }

        //cout << "\n\nConstrutivo NEH" << endl;
        Solucao_NEH = execute_construtivoSetup_NEHTRB(dataSetup, matriz_vel_teste);
        All_Solution.push_back(Solucao_NEH);

        //NEH com VND
        Solucao_VND = VND_local_search(Solucao_NEH.sequence, dataSetup, Solucao_NEH.makespan, matriz_vel_teste);
        All_Solution.push_back(Solucao_VND);

        Solucao_energy_saving = energy_saving_adaptado(dataSetup, Solucao_VND.sequence, Solucao_VND.matriz_velocidade, Solucao_VND.makespan, Solucao_VND.energia);
        All_Solution.push_back(Solucao_energy_saving);

        min_value = std::numeric_limits<float>::max();
    }

    Dominate(All_Solution);

    segunda_fase(All_Solution, dataSetup);

    Dominate(All_Solution);

    double CPU_Time = timer.stop();

    // Calculating total time taken by the program.
    std::cout.precision(5);
    cout << "CPU TIME: " << fixed << CPU_Time;
    cout << " sec " << endl;
    //***********************************FIM**************************************************************

    cout << "\nSolucoes nao dominadas: " << endl;

    cout << "makespan" << "   " << "energia" << endl;
    for (int z = 0; z < All_Solution.size(); z++) {
        cout << All_Solution[z].makespan << "     " << All_Solution[z].energia << endl;
    }

    //pair <float, float> nadir_point;
    //nadir_point.first = 1.1 * All_Solution.back().makespan;
    //cout << nadir_point.first << endl;
    //nadir_point.second = 1.1 * All_Solution.front().energia;
    //cout << nadir_point.second << endl;

    float hipervolume = hypervolume(All_Solution, nadir_point);

    // salvando makespan e energia das solu��es n�o dominadas em arquivo pra pareto front

    escrever_nds(All_Solution, nomeInstanciaSetup, modelo);

    //resumo de metricas

    escrever_resumo(All_Solution, nomeInstanciaSetup, CPU_Time, hipervolume, modelo);

    //salvando solu��es n�o dominadas em arquivo

    escrever_solucao_completa(All_Solution, nomeInstanciaSetup, CPU_Time, hipervolume, dataSetup, modelo);

}

pair<float,float> NEH_Swap_modifRK(string instancia, string modelo) {

    Timer timer;
    timer.start();

    string nomeInstanciaSetup = instancia;
    cout << "\n";
    cout << nomeInstanciaSetup << endl;
    cout << "\n";

    DataSetup dataSetup;
    carregarInstanciaSetup(nomeInstanciaSetup, dataSetup);


    // defini��o matriz de velocidades
    int nivel_velocidade = 2;
    vector<vector<int>> matriz_vel_teste;

    matriz_vel_teste.resize(dataSetup.n);
    for (int i = 0; i < dataSetup.n; i++) {
        matriz_vel_teste[i].resize(dataSetup.m);
    }

    vector<Results> All_Solution;

    //cout << "Matriz de velocidade inicial: "<< nivel_velocidade << "\n" << endl;
    for (int i = 0; i < dataSetup.n; i++) {
        for (int j = 0; j < dataSetup.m; j++) {
            if (j == 2) {
		        matriz_vel_teste[i][j] = nivel_velocidade;            	
            } else {
            	matriz_vel_teste[i][j] = 0;
            }
            //cout << matriz_vel_teste[i][j] << "\t";
        }
        //cout << "\n";
    }

    //cout << "\n\nConstrutivo NEH" << endl;
    Results Solucao_NEH = execute_construtivoSetup_NEHTRB(dataSetup, matriz_vel_teste);
    All_Solution.push_back(Solucao_NEH);


    //NEH com VND
    Results Solucao_Swap = Swap_local_search(Solucao_NEH.sequence, dataSetup, Solucao_NEH.makespan, matriz_vel_teste);
    All_Solution.push_back(Solucao_Swap);

    //cout << Solucao_VND.makespan << "\t" << Solucao_VND.energia << endl;

    //Results Solucao_energy_saving = energy_saving_adaptado(dataSetup, Solucao_Swap.sequence, matriz_vel_teste, Solucao_Swap.makespan, Solucao_Swap.energia);
    //All_Solution.push_back(Solucao_energy_saving);

    //cout << Solucao_energy_saving.makespan << "\t" << Solucao_energy_saving.energia << endl;
    //cout << "*********************************" << endl;

    bool teste = true;
    vector<vector<float>> p_atualizado;
    p_atualizado.resize(dataSetup.n);
    for (int i = 0; i < dataSetup.n; i++) {
        p_atualizado[i].resize(dataSetup.m);
    }
    float min_value = std::numeric_limits<float>::max();  // Valor inicial m�ximo poss�vel
    int min_row = -1;
    int min_col = -1;
	
	int contador = 0;
    while (teste == true) {
    	std::cout << ++contador << endl;
    	
        teste = false;

        for (int i = 0; i < dataSetup.n; i++) {
            for (int j = 0; j < dataSetup.m; j++) {
                p_atualizado[i][j] = dataSetup.p[i][j] / dataSetup.speed[j][matriz_vel_teste[i][j]];
            }
        }

        for (int i = 0; i < dataSetup.n; i++) {
            for (int j = 0; j < dataSetup.m; j++) {
                if (p_atualizado[i][j] < min_value && matriz_vel_teste[i][j] > 0 && j == 2) {
                    min_value = p_atualizado[i][j];
                    min_row = i;
                    min_col = j;
                    teste = true;
                }
            }
        }

        if (matriz_vel_teste[min_row][min_col] > 0) {
            matriz_vel_teste[min_row][min_col]--;
        }

        //cout << "\n\nConstrutivo NEH" << endl;
        Solucao_NEH = execute_construtivoSetup_NEHTRB(dataSetup, matriz_vel_teste);
        All_Solution.push_back(Solucao_NEH);

        //NEH com VND
        Solucao_Swap = Swap_local_search(Solucao_NEH.sequence, dataSetup, Solucao_NEH.makespan, matriz_vel_teste);
        All_Solution.push_back(Solucao_Swap);

        //Results Solucao_energy_saving = energy_saving_adaptado(dataSetup, Solucao_Swap.sequence, Solucao_Swap.matriz_velocidade, Solucao_Swap.makespan, Solucao_Swap.energia);
        //All_Solution.push_back(Solucao_energy_saving);

        min_value = std::numeric_limits<float>::max();
    }

    Dominate(All_Solution);

    //segunda_fase(All_Solution, dataSetup);

    //Dominate(All_Solution);

    double CPU_Time = timer.stop();

    // Calculating total time taken by the program.
    std::cout.precision(5);
    cout << "CPU TIME: " << fixed << CPU_Time;
    cout << " sec " << endl;
    //***********************************FIM**************************************************************

    cout << "\nSolucoes nao dominadas: " << endl;

    cout << "makespan" << "   " << "energia" << endl;
    for (int z = 0; z < All_Solution.size(); z++) {
        cout << All_Solution[z].makespan << "     " << All_Solution[z].energia << endl;
    }

    pair <float, float> nadir_point;
    nadir_point.first = 1.1 * All_Solution.back().makespan;
    //cout << nadir_point.first << endl;
    nadir_point.second = 1.1 * All_Solution.front().energia;
    //cout << nadir_point.second << endl;

    float hipervolume = hypervolume(All_Solution, nadir_point);

    // salvando makespan e energia das solu��es n�o dominadas em arquivo pra pareto front

    escrever_nds(All_Solution, nomeInstanciaSetup, modelo);

    //resumo de metricas

    escrever_resumo(All_Solution, nomeInstanciaSetup, CPU_Time, hipervolume, modelo);

    //salvando solu��es n�o dominadas em arquivo

    escrever_solucao_completa(All_Solution, nomeInstanciaSetup, CPU_Time, hipervolume, dataSetup, modelo);

    return nadir_point;
}

void NEH_VND_energy_saving_modifRK(string instancia, string modelo, pair<float,float> nadir_point) {

    Timer timer;
    timer.start();

    string nomeInstanciaSetup = instancia;
    cout << "\n";
    cout << nomeInstanciaSetup << endl;
    cout << "\n";

    DataSetup dataSetup;
    carregarInstanciaSetup(nomeInstanciaSetup, dataSetup);


    // defini��o matriz de velocidades
    int nivel_velocidade = 2;
    vector<vector<int>> matriz_vel_teste;

    matriz_vel_teste.resize(dataSetup.n);
    for (int i = 0; i < dataSetup.n; i++) {
        matriz_vel_teste[i].resize(dataSetup.m);
    }

    vector<Results> All_Solution;

    //cout << "Matriz de velocidade inicial: "<< nivel_velocidade << "\n" << endl;
    for (int i = 0; i < dataSetup.n; i++) {
        for (int j = 0; j < dataSetup.m; j++) {
            if (j == 2) {
		        matriz_vel_teste[i][j] = nivel_velocidade;            	
            } else {
            	matriz_vel_teste[i][j] = 0;  
            }
            //cout << matriz_vel_teste[i][j] << "\t";
        }
        //cout << "\n";
    }

    //cout << "\n\nConstrutivo NEH" << endl;
    Results Solucao_NEH = execute_construtivoSetup_NEHTRB(dataSetup, matriz_vel_teste);
    All_Solution.push_back(Solucao_NEH);


    //NEH com VND
    Results Solucao_VND = VND_local_search(Solucao_NEH.sequence, dataSetup, Solucao_NEH.makespan, matriz_vel_teste);
    All_Solution.push_back(Solucao_VND);

    //cout << Solucao_VND.makespan << "\t" << Solucao_VND.energia << endl;

    Results Solucao_energy_saving = energy_saving_adaptado(dataSetup, Solucao_VND.sequence, matriz_vel_teste, Solucao_VND.makespan, Solucao_VND.energia);
    All_Solution.push_back(Solucao_energy_saving);

    //cout << Solucao_energy_saving.makespan << "\t" << Solucao_energy_saving.energia << endl;
    //cout << "*********************************" << endl;

    bool teste = true;
    vector<vector<float>> p_atualizado;
    p_atualizado.resize(dataSetup.n);
    for (int i = 0; i < dataSetup.n; i++) {
        p_atualizado[i].resize(dataSetup.m);
    }
    float min_value = std::numeric_limits<float>::max();  // Valor inicial m�ximo poss�vel
    int min_row = -1;
    int min_col = -1;

	int contador = 0;
    while (teste == true) {
    	std::cout << ++contador << endl;

        teste = false;

        for (int i = 0; i < dataSetup.n; i++) {
            for (int j = 0; j < dataSetup.m; j++) {
                p_atualizado[i][j] = dataSetup.p[i][j] / dataSetup.speed[j][matriz_vel_teste[i][j]];
            }
        }

        for (int i = 0; i < dataSetup.n; i++) {
            for (int j = 0; j < dataSetup.m; j++) {
                if (p_atualizado[i][j] < min_value && matriz_vel_teste[i][j] > 0 && j == 2) {
                    min_value = p_atualizado[i][j];
                    min_row = i;
                    min_col = j;
                    teste = true;
                }
            }
        }

        if (matriz_vel_teste[min_row][min_col] > 0) {
            matriz_vel_teste[min_row][min_col]--;
        }

        //cout << "\n\nConstrutivo NEH" << endl;
        Solucao_NEH = execute_construtivoSetup_NEHTRB(dataSetup, matriz_vel_teste);
        All_Solution.push_back(Solucao_NEH);

        //NEH com VND
        Solucao_VND = VND_local_search(Solucao_NEH.sequence, dataSetup, Solucao_NEH.makespan, matriz_vel_teste);
        All_Solution.push_back(Solucao_VND);

        Solucao_energy_saving = energy_saving_adaptado(dataSetup, Solucao_VND.sequence, Solucao_VND.matriz_velocidade, Solucao_VND.makespan, Solucao_VND.energia);
        All_Solution.push_back(Solucao_energy_saving);

        min_value = std::numeric_limits<float>::max();
    }

    Dominate(All_Solution);

    //segunda_fase(All_Solution, dataSetup);

    //Dominate(All_Solution);

    double CPU_Time = timer.stop();

    // Calculating total time taken by the program.
    std::cout.precision(5);
    cout << "CPU TIME: " << fixed << CPU_Time;
    cout << " sec " << endl;
    //***********************************FIM**************************************************************

    cout << "\nSolucoes nao dominadas: " << endl;

    cout << "makespan" << "   " << "energia" << endl;
    for (int z = 0; z < All_Solution.size(); z++) {
        cout << All_Solution[z].makespan << "     " << All_Solution[z].energia << endl;
    }

    //pair <float, float> nadir_point;
    //nadir_point.first = 1.1 * All_Solution.back().makespan;
    //cout << nadir_point.first << endl;
    //nadir_point.second = 1.1 * All_Solution.front().energia;
    //cout << nadir_point.second << endl;

    float hipervolume = hypervolume(All_Solution, nadir_point);

    // salvando makespan e energia das solu��es n�o dominadas em arquivo pra pareto front

    escrever_nds(All_Solution, nomeInstanciaSetup, modelo);

    //resumo de metricas

    escrever_resumo(All_Solution, nomeInstanciaSetup, CPU_Time, hipervolume, modelo);

    //salvando solu��es n�o dominadas em arquivo

    escrever_solucao_completa(All_Solution, nomeInstanciaSetup, CPU_Time, hipervolume, dataSetup, modelo);

}
