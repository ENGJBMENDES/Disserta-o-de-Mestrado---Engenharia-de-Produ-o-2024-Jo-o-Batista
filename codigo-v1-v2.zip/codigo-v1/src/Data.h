#ifndef DATA_H_INCLUDED
#define DATA_H_INCLUDED

#include <vector>

struct Data {
    int m;
    int n;
    std::vector<std::vector<int>> p;
};

struct DataSetup {
    int m;
    int n;
    std::vector<std::vector<float>> p;
    std::vector<std::vector<std::vector<int>>> s;
//    std::vector<float> speed;
	std::vector<std::vector<float>> speed;
//    std::vector<float> lambda;
    std::vector<std::vector<float>> lambda;
};

#endif // DATA_H_INCLUDED

