//
// Created by luciano on 2020-06-04.
//

#ifndef MARKETDISCOVERY_TIMER_H
#define MARKETDISCOVERY_TIMER_H

#include <chrono>

class Timer {

public:

    Timer() {
        total = 0;
        running = false;
    };

    void start() {
        if (running) return;
        start_point = std::chrono::system_clock::now();
        running = true;
    }

    [[nodiscard]] double lap() {
        if (!running) return std::numeric_limits<double>::infinity();
        auto x = std::chrono::system_clock::now();
        return (total = std::chrono::duration_cast<std::chrono::milliseconds>(x - start_point).count() / 1000.0);
    }

    double stop() {
        double temp = lap();
        running = false;
        total = temp;
        return temp;
    }

    [[nodiscard]] double get() const { return total; }

private:

    std::chrono::time_point<std::chrono::system_clock> start_point;
    bool running;
    double total;
};

#endif //MARKETDISCOVERY_TIMER_H