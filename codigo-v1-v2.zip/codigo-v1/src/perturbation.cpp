using namespace std;

#include <ctime>
#include <random>
#include "perturbation.h"
#include "ConstrutivoSetup.h"
#include "localSearch.h"
#include <iostream>
#include <limits>


vector<int> perturbation(vector<int>& sequence, const DataSetup& data, vector<vector<int>>& matriz_speed) {

    vector<int> sequence_perturbation;
    sequence_perturbation = sequence;

    vector<int> pos_perturb;
    pos_perturb.resize(6);

    //cout << "\n\nAs posicoes escolhidas para fazer a perturbacao sao: ";

    for (int i = 0; i < pos_perturb.size(); i++) {

        pos_perturb[i] = rand() % data.n;
        //cout << pos_perturb[i] << " ";

    }
    //cout << endl;

    int troca;

    for (int i = 0; i < pos_perturb.size() - 1; i += 2) {
        troca = sequence_perturbation[pos_perturb[i]];
        sequence_perturbation[pos_perturb[i]] = sequence_perturbation[pos_perturb[i + 1]];
        sequence_perturbation[pos_perturb[i + 1]] = troca;
    }


    /*cout << "Portanto, a sequencia realizada a perturbacao eh: ";
    for (int j = 0; j < data.n; j++) {
        cout << sequence_perturbation[j] << " ";
    }*/

    vector<vector<float>> perturb_makespan;
    perturb_makespan = calcMakespanSetup(sequence_perturbation, data, matriz_speed);
    //cout << "\nCom um makespan de " << perturb_makespan[data.n - 1][data.m - 1] << endl;

    /*random_device rd;
    mt19937 mt(rd());
    uniform_int_distribution <int> dist (0, data.n-1);

    for (int i = 0; i < 6; i++){
        cout << dist(mt) << " ";
    }

    cout << endl;
    */
    return sequence_perturbation;
}




Results criterio_aceitacao(vector<int>& sequence, const DataSetup& data, vector<vector<int>>& matriz_speed) {

    /*srand(time(NULL)); */
    srand(0);

    int nbIterSemMelhoria = 0;
    int MaxIterSemMelhorias = 5;

    vector<int> perturb_sequence;

    vector<int> perturb_local_search_sequence;
    vector<vector<float>> perturb_local_search_makespan;

    vector<int> best_sequence = sequence;
    vector<vector<float>> makespan;


    while (nbIterSemMelhoria < MaxIterSemMelhorias) {

        makespan = calcMakespanSetup(best_sequence, data, matriz_speed);
        perturb_sequence = perturbation(best_sequence, data, matriz_speed);
        Results perturb_local_search = VND_local_search(perturb_sequence,data, makespan[data.n - 1][data.m - 1], matriz_speed);

        if (perturb_local_search.makespan < makespan[data.n - 1][data.m - 1]) {
            best_sequence = perturb_local_search.sequence;
            //cout << "Houve melhora com a perturbacao\n" << endl;
            nbIterSemMelhoria = 0;
        }

        else {
            nbIterSemMelhoria++;
            //cout << "Nao houve melhora com a perturbacao" << endl;
            //cout << "Iteracao: " << nbIterSemMelhoria << endl;
        }
    }

    /*cout << "\n\nPortanto, a melhor sequencia com perturbacao e busca local eh: ";
    for (int i = 0; i < data.n; i++) {
        cout << best_sequence[i] << " ";
    }
    cout << "\nO menor makespan encontrado eh: " << makespan[data.n - 1][data.m - 1] << endl;*/

    float energia = calcTEC(best_sequence, makespan[data.n - 1][data.m - 1], data, matriz_speed);

    Results Resultados;

    Resultados.sequence = best_sequence;
    Resultados.energia = energia;
    Resultados.makespan = makespan[data.n - 1][data.m - 1];
    Resultados.matriz_velocidade = matriz_speed;

    return Resultados;
}


vector<vector<int>> perturbation_speed(const DataSetup& data, vector<vector<int>>& matriz_speed, float p) {
    
    vector<vector<int>> matriz_speed_perturbation;
    matriz_speed_perturbation = matriz_speed;

    vector<vector<int>> pos_perturb;

    int n_jobs = data.n;
    int jobs_speed_perturbation = n_jobs * p;

    pos_perturb.resize(jobs_speed_perturbation);
    for (int i = 0; i < jobs_speed_perturbation; i++) {
        pos_perturb[i].resize(2);
    }
    

    //cout << "\n\nAs posicoes escolhidas para fazer a perturbacao sao: ";

    for (int i = 0; i < jobs_speed_perturbation; i++) {
        for (int j = 0; j < 2; j++) {

            if (j == 0) {
                pos_perturb[i][j] = rand() % data.n;
            }
            if (j == 1) {
                pos_perturb[i][j] = rand() % data.m;
            }
            //cout << pos_perturb[i][j] << " ";

        }
        //cout << endl;
    }

    for (int i = 0; i < jobs_speed_perturbation; i++) {

        matriz_speed_perturbation[pos_perturb[i][0]][pos_perturb[i][1]] = rand() % data.speed[0].size();
        //cout << matriz_speed_perturbation[pos_perturb[i][0]][pos_perturb[i][1]] << endl;
        
        /*if (data.p[pos_perturb[i][0]][pos_perturb[i][1]] >= 1 && data.p[pos_perturb[i][0]][pos_perturb[i][1]] < 33) {
            matriz_speed_perturbation[pos_perturb[i][0]][pos_perturb[i][1]] = 0;
        }
        else if (data.p[pos_perturb[i][0]][pos_perturb[i][1]] >= 33 && data.p[pos_perturb[i][0]][pos_perturb[i][1]] < 66) {
            matriz_speed_perturbation[pos_perturb[i][0]][pos_perturb[i][1]] = 1;
        }
        else if (data.p[pos_perturb[i][0]][pos_perturb[i][1]] >= 66 && data.p[pos_perturb[i][0]][pos_perturb[i][1]] <= 99) {
            matriz_speed_perturbation[pos_perturb[i][0]][pos_perturb[i][1]] = 2;
        }*/


    }
        
    /*cout << "A Matriz de velocidade perturbada eh: " << endl;
    for (int i = 0; i < data.n; i++) {
        for (int j = 0; j < data.m; j++) {
            cout << matriz_speed_perturbation[i][j] << "\t";
        }
        cout << "\n";
    }*/

    return matriz_speed_perturbation;
}
