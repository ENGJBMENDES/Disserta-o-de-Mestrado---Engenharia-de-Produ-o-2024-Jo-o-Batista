#ifndef LOCALSEARCH_H_INCLUDED
#define LOCALSEARCH_H_INCLUDED

#include <vector>
#include "Data.h"
#include "Solution.h"

Results exchange(std::vector<int>& sequence, const DataSetup& data, std::vector<vector<int>>& matriz_speed);

Results insertion(std::vector<int>& sequence, const DataSetup& data, std::vector<vector<int>>& matriz_speed);

Results OrOpt(std::vector<int>& sequence, const DataSetup& data, int korOpt, std::vector<vector<int>>& matriz_speed);

Results twoOpt(std::vector<int>& sequence, const DataSetup& data, std::vector<vector<int>>& matriz_speed);

Results bloco_exchange(std::vector<int>& sequence, const DataSetup& data, int blocos, std::vector<vector<int>>& matriz_speed);

Results VND_local_search(std::vector<int>& sequence, const DataSetup& data, float mkspn, std::vector<vector<int>>& matriz_speed);

Results Swap_local_search(std::vector<int>& sequence, const DataSetup& data, float mkspn, std::vector<vector<int>>& matriz_speed);

Results local_search_velocidades(std::vector<int>& sequence, const DataSetup& data, std::vector<vector<int>>& matriz_speed, int& nivel);

std::vector<vector<float>> Gap_J(std::vector<int>& sequence, const DataSetup& data, std::vector<vector<int>>& matriz_speed);

std::vector<vector<float>> Gap_M(std::vector<int>& sequence, const DataSetup& data, std::vector<vector<int>>& matriz_speed);

std::vector<vector<float>> Gap(const DataSetup& data, std::vector<vector<float>>& Gap_J, std::vector<vector<int>>& Gap_M);

std::vector<pair<int,int>> G(const DataSetup& data, std::vector<vector<float>>& Gap);

float calcTecUnit(vector<int> sequence, std::pair<int, int> G, const DataSetup& data, vector<vector<int>>& matriz_speed);

vector<float> E_C(vector<int> sequence,vector<pair<int, int>> G, const DataSetup& data, vector<vector<int>>& matriz_speed);

Results energy_saving(const DataSetup& data, vector<int> sequence, vector<vector<float>>& matriz_speed, float energy);

Results energy_saving_adaptado(const DataSetup& data, vector<int> sequence, vector<vector<int>>& matriz_speed, float makespan, float energy);

float soma_Gap(const DataSetup& data, vector<vector<float>> Gap);

#endif // LOCALSEARCH_H_INCLUDED

