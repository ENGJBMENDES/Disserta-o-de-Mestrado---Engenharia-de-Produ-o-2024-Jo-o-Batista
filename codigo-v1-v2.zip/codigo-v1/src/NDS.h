#ifndef NDS_H_INCLUDED
#define NDS_H_INCLUDED

#include "Solution.h"
#include <cmath>

void Dominate(std::vector<Results>& All_Solution);

bool dominantes(float a1, float b1, float a2, float b2);

#endif // NDS_H_INCLUDED
