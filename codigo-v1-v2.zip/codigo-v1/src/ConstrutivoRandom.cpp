using namespace std;
#include "ConstrutivoRandom.h"
#include <iostream>
#include <limits>
#include <algorithm>
#include "ConstrutivoSetup.h"


Results sequenceRandom(const DataSetup& data, vector<vector<int>>& matriz_speed) {

    vector<int> sequence;
    sequence.resize(data.n);

    for (int i = 0; i < sequence.size(); i++) {

        sequence[i] = i;

    }

    //std::srand(unsigned(0));
    //std::srand(unsigned(std::time(0)));

    random_shuffle(sequence.begin(), sequence.end());

    /*cout << "\nA sequencia aleatoria eh: ";
    for (int i = 0; i < sequence.size(); i++) {

        cout << sequence[i] << " ";

    }
    cout << "\n";*/

    vector<vector<float>> makespan = calcMakespanSetup(sequence, data, matriz_speed);
    //cout << "O makespan encontrado eh: " << makespan[data.n - 1][data.m - 1] << endl;

    float energia = calcTEC(sequence, makespan[data.n - 1][data.m - 1], data, matriz_speed);
    //cout << "A energia consumida eh: " << energia << endl;

    Results Resultados;

    Resultados.sequence = sequence;
    Resultados.energia = energia;
    Resultados.makespan = makespan[data.n - 1][data.m - 1];
    Resultados.matriz_velocidade = matriz_speed;

    return Resultados;
}