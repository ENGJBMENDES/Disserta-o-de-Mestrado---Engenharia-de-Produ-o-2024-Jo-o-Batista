#include "Solution.h"
#include "Data.h"
#include <string>
#include <fstream>

#ifndef RESULTADO_H_INCLUDED
#define RESULTADO_H_INCLUDED

string obtemNomeDaInstancia( string instancePath );
void escrever_nds(vector<Results> All_Solution, string nomeInstanciaSetup, string modelo);
void escrever_solucao_completa(vector<Results> All_Solution, string nomeInstanciaSetup, double CPU_Time, float hipervolume, const DataSetup& dataSetup, string modelo);
void escrever_resumo(vector<Results> All_Solution, string nomeInstanciaSetup, double CPU_Time, float hipervolume, string modelo);


#endif // RESULTADO_H_INCLUDED
